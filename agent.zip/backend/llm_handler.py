# backend/llm_handler.py
import os
from langchain_ollama import OllamaLLM

OLLAMA_BASE_URL = "http://10.11.3.181:11434"
# remote server hosting the models



# Map friendly names to your actual Ollama models (update these names if different)
MODEL_MAP = {
    "deepseek-70b": "deepseek-r1:70b",
    "deepseek-coder-33b": "deepseek-coder:33b",
    "qwen3": "Qwen3",
}

def call_model(prompt: str, model_name: str = None, max_tokens: int = 2048):
    model = MODEL_MAP.get(model_name, model_name) if model_name else MODEL_MAP["deepseek-70b"]
    try:
        llm = OllamaLLM(model=model, base_url=OLLAMA_BASE_URL)
        # Some Ollama clients via LangChain use .invoke, others call llm.generate; OllamaLLM provides .invoke in prior code
        try:
            res = llm.invoke(prompt, max_tokens=max_tokens)
        except TypeError:
            # fallback
            res = llm(prompt)
        if isinstance(res, str):
            return res.strip()
        # if LangChain returns an object
        try:
            out = getattr(res, "text", None) or str(res)
            return out.strip()
        except Exception:
            return str(res)
    except Exception as e:
        return f"❌ LLM error: {e}"
