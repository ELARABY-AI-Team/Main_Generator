from rag_manager import get_vectorstore

db = get_vectorstore()
docs = db.get()["documents"]

print(f"Total docs in Chroma: {len(docs)}")
for i, doc in enumerate(docs):
    source = doc.metadata.get("source", "<unknown>")
    content_preview = doc.page_content[:100].replace("\n", " ")
    print(f"Doc {i}: {source} | {content_preview}...")
