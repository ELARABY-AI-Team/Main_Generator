import sys
import os
import re
import requests
import threading
from PyPDF2 import PdfReader
import docx
from PIL import Image
import pytesseract
import xml.etree.ElementTree as ET
from pdf2image import convert_from_path
import pdfplumber
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QTextEdit,
    QLineEdit,
    QPushButton,
    QLabel,
    QFileDialog
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Optional paths (set manually if needed)
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
# poppler_path = r"C:\poppler\Library\bin"  # if not in PATH


# ===============================================
# 🛰️ DeepSeek API CALL
# ===============================================
def call_deepseek_api(prompt):
    url = "http://10.11.3.181:11434/api/generate"
    headers = {"Content-Type": "application/json"}
    data = {
        "model": "deepseek-r1:70b",
        "prompt": prompt,
        "stream": False,
        "stop": ["User:", "Assistant:", "<think>", "</think>", "🧑", "🤖"]
    }

    try:
        response = requests.post(url, headers=headers, json=data, timeout=300)
        response.raise_for_status()
        result = response.json()

        reply = result.get("response", "").strip()
        if not reply and "data" in result:
            reply = result["data"]

        reply = re.sub(r"<think>.*?</think>", "", reply, flags=re.DOTALL)
        reply = re.sub(r"User:.*", "", reply).strip()
        return reply or "⚠️ Empty response from model."
    except Exception as e:
        return f"❌ Error: {e}"


# ===============================================
# 🧠 MEMORY MANAGER
# ===============================================
class MemoryManager:
    def __init__(self):
        self.memory = []
        self.vectorizer = TfidfVectorizer()

    def add(self, user_input, model_output):
        self.memory.append(f"User: {user_input}\nAssistant: {model_output}")

    def recall(self, query, top_k=3):
        if not self.memory:
            return ""
        docs = self.memory + [query]
        vectors = self.vectorizer.fit_transform(docs)
        similarities = cosine_similarity(vectors[-1:], vectors[:-1]).flatten()
        top_indices = similarities.argsort()[-top_k:][::-1]
        return "\n\n".join([self.memory[i] for i in top_indices])


# ===============================================
# 🪟 GUI APPLICATION
# ===============================================
class AgentApp(QWidget):
    response_ready = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.memory = MemoryManager()
        self.response_ready.connect(self.update_ui, Qt.ConnectionType.QueuedConnection)

        self.setWindowTitle("DeepSeek Agent (Flowchart + Datasheet Reader)")
        self.setGeometry(100, 100, 850, 650)
        self.uploaded_files = {}

        # === Layouts & Widgets ===
        self.layout = QVBoxLayout()
        self.file_buttons_layout = QHBoxLayout()

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText("Type your message...")
        self.send_button = QPushButton("Send")
        self.status_label = QLabel("✅ Ready")

        self.upload_flowchart = QPushButton("📈 Upload Flowchart")
        self.upload_pdf = QPushButton("📄 Upload PDF")
        self.upload_word = QPushButton("📝 Upload Word")
        self.upload_visio = QPushButton("📊 Upload Visio")

        # Layout assembly
        self.file_buttons_layout.addWidget(self.upload_flowchart)
        self.file_buttons_layout.addWidget(self.upload_pdf)
        self.file_buttons_layout.addWidget(self.upload_word)
        self.file_buttons_layout.addWidget(self.upload_visio)

        self.layout.addWidget(self.chat_display)
        self.layout.addLayout(self.file_buttons_layout)
        self.layout.addWidget(self.input_box)
        self.layout.addWidget(self.send_button)
        self.layout.addWidget(self.status_label)
        self.setLayout(self.layout)

        # Connections
        self.send_button.clicked.connect(self.send_message)
        self.input_box.returnPressed.connect(self.send_message)
        self.upload_flowchart.clicked.connect(lambda: self.upload_file("Flowchart", ["*.png", "*.jpg", "*.jpeg", "*.svg"]))
        self.upload_pdf.clicked.connect(lambda: self.upload_file("PDF", ["*.pdf"]))
        self.upload_word.clicked.connect(lambda: self.upload_file("Word", ["*.docx"]))
        self.upload_visio.clicked.connect(lambda: self.upload_file("Visio", ["*.vsd", "*.vsdx"]))

    # ==========================================
    # 📁 Upload and Extract
    # ==========================================
    def upload_file(self, file_type, extensions):
        file_filter = f"{file_type} Files ({' '.join(extensions)})"
        file_path, _ = QFileDialog.getOpenFileName(self, f"Select {file_type}", "", file_filter)
        if not file_path:
            return

        file_name = os.path.basename(file_path)
        text_content = ""

        try:
            # ----- PDF -----
            if file_type == "PDF":
                text_content = ""
                try:
                    with pdfplumber.open(file_path) as pdf:
                        for page in pdf.pages:
                            # Extract normal text
                            page_text = page.extract_text() or ""
                            text_content += page_text

                            # Extract tables
                            tables = page.extract_tables()
                            for table in tables:
                                for row in table:
                                    text_content += " | ".join(str(cell) for cell in row if cell) + "\n"

                except Exception as e:
                    text_content = f"[PDF text/table extraction failed: {e}]"

                # OCR fallback
                if not text_content.strip():
                    try:
                        images = convert_from_path(file_path)
                        ocr_text = ""
                        for img in images:
                            ocr_text += pytesseract.image_to_string(img)
                        text_content = ocr_text.strip() or "[No readable text found in PDF]"
                    except Exception as e:
                        text_content = f"[PDF OCR failed: {e}]"

            # ----- Word (.docx) -----
            elif file_type == "Word":
                doc = docx.Document(file_path)
                text_content = "\n".join([p.text for p in doc.paragraphs]) or "[No text in DOCX]"

            # ----- Flowchart (image or SVG) -----
            elif file_type == "Flowchart":
                lower = file_path.lower()
                if lower.endswith(".svg"):
                    try:
                        tree = ET.parse(file_path)
                        root = tree.getroot()
                        texts = []
                        for elem in root.iter():
                            if elem.text and elem.text.strip():
                                texts.append(elem.text.strip())
                        text_content = "\n".join(texts) or f"[No text elements found in SVG {file_name}]"
                    except Exception as e:
                        text_content = f"[Error reading SVG: {e}]"
                else:
                    try:
                        img = Image.open(file_path)
                        ocr_text = pytesseract.image_to_string(img)
                        text_content = ocr_text.strip() or f"[No readable text detected in {file_name}]"
                    except Exception as e:
                        text_content = f"[Flowchart OCR error: {e}]"

            # ----- Visio (.vsdx / .vsd) -----
            elif file_type == "Visio":
                lower = file_path.lower()
                if lower.endswith(".vsdx"):
                    try:
                        from vsdx import VisioFile
                        vf = VisioFile(file_path)
                        texts = []
                        for page in vf.pages:
                            for shape in page.shapes:
                                try:
                                    if shape.text and shape.text.strip():
                                        texts.append(shape.text.strip())
                                except Exception:
                                    continue
                        text_content = "\n".join(texts) if texts else f"[No text found in {file_name}]"
                    except Exception as e:
                        text_content = f"[Error reading .vsdx: {e}]"
                else:
                    text_content = "[Old .vsd format not supported. Save as .vsdx in MS Visio.]"

            # Save and show
            self.uploaded_files[file_name] = text_content.strip()
            self.chat_display.append(f"📂 Uploaded {file_type}: {file_name}")

        except Exception as e:
            self.chat_display.append(f"❌ Error reading {file_type}: {e}")

    # ==========================================
    # 📤 Send Message (Flowchart-Aware)
    # ==========================================
    def send_message(self):
        user_text = self.input_box.text().strip()
        if not user_text:
            return

        self.chat_display.append(f"🧑 You: {user_text}")
        self.input_box.clear()
        self.status_label.setText("🤖 Thinking...")

        context = self.memory.recall(user_text)

        # Check if a flowchart is uploaded
        is_flowchart = any("Flowchart" in name for name in self.uploaded_files.keys())

        if self.uploaded_files:
            all_files_text = "\n\n".join(
                [f"--- {name} ---\n{(content or '')[:6000]}" for name, content in self.uploaded_files.items()]
            )

            if is_flowchart:
                context += (
                    f"\n\n[Flowchart OCR Interpretation]\n"
                    f"The following text was extracted from a flowchart image. "
                    f"Interpret it step-by-step and describe the process, decisions, and logical flow clearly:\n\n"
                    f"{all_files_text}"
                )
            else:
                context += f"\n\n[Uploaded Files Content]\n{all_files_text}"

        full_prompt = f"{context}\n\nUser: {user_text}\nAssistant:"

        threading.Thread(
            target=self.process_message,
            args=(user_text, full_prompt),
            daemon=True
        ).start()

    # ==========================================
    # ⚙️ Background Worker
    # ==========================================
    def process_message(self, user_text, full_prompt):
        model_output = call_deepseek_api(full_prompt)
        self.memory.add(user_text, model_output)
        self.response_ready.emit(model_output)

    # ==========================================
    # 🖥️ Update UI
    # ==========================================
    def update_ui(self, model_output):
        self.chat_display.append(f"🤖 DeepSeek: {model_output}\n")
        self.status_label.setText("✅ Ready")


# ===============================================
# ▶️ Run Application
# ===============================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AgentApp()
    window.show()
    sys.exit(app.exec())
