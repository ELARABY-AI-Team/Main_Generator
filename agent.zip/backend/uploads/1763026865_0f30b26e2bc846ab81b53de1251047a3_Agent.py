import sys
import re
import requests
import threading
from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QTextEdit,
    QLineEdit,
    QPushButton,
    QLabel
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ===============================================
# 🛰️ DeepSeek API CALL  #qwen3:lastest  #deepseek-coder:33b
# ===============================================
def call_deepseek_api(prompt):
    """
    Send prompt to DeepSeek local API and return clean response text.
    """
    url = "http://10.11.3.181:11434/api/generate"
    headers = {"Content-Type": "application/json"}
    data = {
        "model": "deepseek-r1:70b",
        "prompt": prompt,
        "stream": False,
        "stop": ["User:", "Assistant:", "<think>", "</think>", "🧑", "🤖"]
    }

    try:
        response = requests.post(url, headers=headers, json=data, timeout=300)
        response.raise_for_status()
        result = response.json()

        # Handle both possible response keys
        reply = result.get("response", "").strip()
        if not reply and "data" in result:
            reply = result["data"]

        # Remove hidden thought sections and user echoes
        reply = re.sub(r"<think>.*?</think>", "", reply, flags=re.DOTALL)
        reply = re.sub(r"User:.*", "", reply).strip()

        return reply or "⚠️ Empty response from model."
    except Exception as e:
        return f"❌ Error: {e}"


# ===============================================
# 🧠 MEMORY MANAGER (TF-IDF + Cosine Similarity)
# ===============================================
class MemoryManager:
    def __init__(self):
        self.memory = []
        self.vectorizer = TfidfVectorizer()

    def add(self, user_input, model_output):
        """
        Save conversation pair to memory.
        """
        self.memory.append(f"User: {user_input}\nAssistant: {model_output}")

    def recall(self, query, top_k=3):
        """
        Retrieve top similar past interactions for better context.
        """
        if not self.memory:
            return ""
        docs = self.memory + [query]
        vectors = self.vectorizer.fit_transform(docs)
        similarities = cosine_similarity(vectors[-1:], vectors[:-1]).flatten()
        top_indices = similarities.argsort()[-top_k:][::-1]
        context = "\n\n".join([self.memory[i] for i in top_indices])
        return context


# ===============================================
# 🪟 GUI APPLICATION
# ===============================================
class AgentApp(QWidget):
    response_ready = pyqtSignal(str)  # Signal emitted by worker thread

    def __init__(self):
        super().__init__()
        self.memory = MemoryManager()

        # Connect signal safely across threads
        self.response_ready.connect(self.update_ui, Qt.ConnectionType.QueuedConnection)

        # Window setup
        self.setWindowTitle("DeepSeek Agent (Async GUI)")
        self.setGeometry(100, 100, 700, 500)

        # Layout and widgets
        self.layout = QVBoxLayout()
        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText("Type your message...")
        self.send_button = QPushButton("Send")
        self.status_label = QLabel("✅ Ready")

        # Button action
        self.send_button.clicked.connect(self.send_message)
        self.input_box.returnPressed.connect(self.send_message)

        # Add widgets
        self.layout.addWidget(self.chat_display)
        self.layout.addWidget(self.input_box)
        self.layout.addWidget(self.send_button)
        self.layout.addWidget(self.status_label)
        self.setLayout(self.layout)

    # ==========================================
    # 📤 Send message → Starts background thread
    # ==========================================
    def send_message(self):
        user_text = self.input_box.text().strip()
        if not user_text:
            return

        self.chat_display.append(f"🧑 You: {user_text}")
        self.input_box.clear()
        self.status_label.setText("🤖 Thinking...")

        # Recall context
        context = self.memory.recall(user_text)
        full_prompt = f"{context}\nUser: {user_text}\nAssistant:"

        # Background thread for model call
        threading.Thread(
            target=self.process_message,
            args=(user_text, full_prompt),
            daemon=True
        ).start()

    # ==========================================
    # ⚙️ Background worker (API call)
    # ==========================================
    def process_message(self, user_text, full_prompt):
        model_output = call_deepseek_api(full_prompt)
        print(f"DEBUG - Model output: {model_output}")  # Debug log
        self.memory.add(user_text, model_output)
        self.response_ready.emit(model_output)

    # ==========================================
    # 🖥️ Update GUI safely via signal
    # ==========================================
    def update_ui(self, model_output):
        self.chat_display.append(f"🤖 DeepSeek: {model_output}\n")
        self.status_label.setText("✅ Ready")


# ===============================================
# ▶️ Run the Application
# ===============================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AgentApp()
    window.show()
    sys.exit(app.exec())
