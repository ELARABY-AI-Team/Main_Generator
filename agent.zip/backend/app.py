# backend/app.py
import os
import time
import uuid
import shutil
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from file_processing import extract_text_from_file
from memory_manager import MemoryManager
from llm_handler import call_model
from rag_manager import add_document, retrieve, CHROMA_DIR
from utils import save_text_to_txt, save_text_to_docx, save_text_to_pdf

BASE_DIR = os.path.dirname(__file__)
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI()

# Serve frontend static files (frontend folder is sibling of backend)
FRONTEND_DIR = os.path.join(BASE_DIR, "..", "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

# CORS (adjust origins for production)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

memory = MemoryManager()
uploads_index = {}  # id -> {orig_name, path, text, uploaded_at}

@app.get("/", response_class=HTMLResponse)
def root():
    # serve frontend/index.html if exists
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            return HTMLResponse(f.read())
    return {"status": "Ragura backend running."}

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    safe_name = f"{int(time.time())}_{uuid.uuid4().hex}_{file.filename}"
    path = os.path.join(UPLOAD_DIR, safe_name)
    content = await file.read()
    with open(path, "wb") as f:
        f.write(content)
    text = extract_text_from_file(path)
    uploads_index[safe_name] = {"original_name": file.filename, "path": path, "text": text, "uploaded_at": time.time()}
    # add to RAG (Chroma)
    try:
        add_document(text, metadata={"source": file.filename})
    except Exception as e:
        return {"filename": file.filename, "chars": len(text), "embedding_error": str(e)}
    return {"filename": file.filename, "chars": len(text)}

@app.post("/chat")
async def chat(message: str = Form(...), model: str = Form(None), k: int = Form(3)):
    # recall memory
    context = memory.recall(message)
    # retrieve from RAG
    retrieved_docs = retrieve(message, k=k)
    retrieved_text = ""
    retrieved_meta = []
    if retrieved_docs:
        chunks = []
        for d in retrieved_docs:
            content = getattr(d, "page_content", str(d))
            meta = getattr(d, "metadata", {})
            src = meta.get("source", "<unknown>")
            chunks.append(f"--- from {src} ---\n{content}")
            retrieved_meta.append(meta)
        retrieved_text = "\n\n".join(chunks)
    full_prompt = f"{context}\n\n[Retrieved Documents]\n{retrieved_text}\n\nUser: {message}\nAssistant:"
    resp = call_model(full_prompt, model_name=model)
    memory.add(message, resp)
    return {"response": resp, "retrieved": retrieved_meta}

@app.get("/list_uploads")
def list_uploads():
    out = []
    for k, v in uploads_index.items():
        out.append({"id": k, "name": v["original_name"], "chars": len(v["text"])})
    return out

@app.get("/download/{file_id}")
def download_file(file_id: str):
    rec = uploads_index.get(file_id)
    if not rec:
        return {"error": "not found"}
    return FileResponse(rec["path"], media_type="application/octet-stream", filename=rec["original_name"])

"""@app.post("/clear_uploads")
def clear_uploads():
    for k, v in list(uploads_index.items()):
        try:
            os.remove(v["path"])
        except Exception:
            pass
        uploads_index.pop(k, None)
    # clear chroma DB
    try:
        shutil.rmtree(CHROMA_DIR)
        os.makedirs(CHROMA_DIR, exist_ok=True)
    except Exception:
        pass
    return {"message": "cleared"}
"""

@app.post("/clear_uploads")
def clear_uploads():
    """
    Clears uploaded files from the server and resets the in-memory uploads index,
    but keeps the RAG (Chroma) database intact.
    """
    for k, v in list(uploads_index.items()):
        try:
            os.remove(v["path"])
        except Exception:
            pass
        uploads_index.pop(k, None)

    return {"message": "uploads cleared, RAG database preserved"}


@app.post("/export")
def export_response(text: str = Form(...), fmt: str = Form("txt")):
    name = f"ragura_response_{int(time.time())}"
    path = os.path.join(UPLOAD_DIR, f"{name}.{fmt}")
    try:
        if fmt == "txt":
            save_text_to_txt(text, path)
        elif fmt == "docx":
            save_text_to_docx(text, path)
        elif fmt == "pdf":
            save_text_to_pdf(text, path)
        else:
            return {"error": "unsupported format"}
        return FileResponse(path, filename=os.path.basename(path))
    except Exception as e:
        return {"error": str(e)}
