# backend/rag_manager.py
import os
from langchain_ollama import OllamaEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document

BASE_DIR = os.path.dirname(__file__)
CHROMA_DIR = os.path.join(BASE_DIR, "chroma_db")
os.makedirs(CHROMA_DIR, exist_ok=True)

OLLAMA_BASE_URL = "http://10.11.3.181:11434"
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "mxbai-embed-large")

embeddings = OllamaEmbeddings(model=EMBEDDING_MODEL, base_url=OLLAMA_BASE_URL)

# Return a Chroma vectorstore instance (connected to same persist dir)
def get_vectorstore():
    return Chroma(persist_directory=CHROMA_DIR, embedding_function=embeddings)

def add_document(text: str, metadata: dict = None, chunk_size: int = 800, chunk_overlap: int = 200):
    splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    docs = splitter.create_documents([text], metadatas=[metadata or {}])
    db = get_vectorstore()
    db.add_documents(docs)
    db.persist()
    
def retrieve(query: str, k: int = 3):
    """Retrieve top-k relevant documents for a query."""
    db = get_vectorstore()
    retriever = db.as_retriever(search_kwargs={"k": k})
    
    # Pass run_manager=None to satisfy new API
    docs = retriever._get_relevant_documents(query, run_manager=None)
    
    return docs
