# backend/app.py
import os
import time
import uuid
import shutil
import re
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from file_processing import extract_text_from_file
from memory_manager import MemoryManager
from llm_handler import call_model
from rag_manager import add_document, retrieve, CHROMA_DIR
from utils import save_text_to_txt, save_text_to_docx, save_text_to_pdf

# NEW IMPORT FOR IMAGE MEMORY (ONLY ADDITION)
from image_memory import add_image, get_images_for_query, clear_image_memory

BASE_DIR = os.path.dirname(__file__)
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = FastAPI()

# Serve frontend static files
FRONTEND_DIR = os.path.join(BASE_DIR, "")
if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

memory = MemoryManager()
uploads_index = {}  


NO_RAG_WORDS = [
    'hello', 'hi', 'hey', 'good morning', 'good afternoon', 'good evening',
    'how are you', 'what\'s up', 'hey there', 'hi there', 'greetings',
    'thank you', 'thanks', 'ok', 'okay', 'yes', 'no', 'bye', 'goodbye',
    'see you', 'talk later', 'ok bye', 'thanks bye', 'thank you bye',
    'good night', 'morning', 'afternoon', 'evening'
]

def should_use_rag(message: str) -> bool:
    if not message:
        return False
    msg = message.lower().strip()
    if len(msg) <= 2:
        return False
    for phrase in NO_RAG_WORDS:
        if re.search(rf"\b{re.escape(phrase)}\b", msg):
            return False
    return True



@app.get("/", response_class=HTMLResponse)
def root():
    index_path = os.path.join(FRONTEND_DIR, "index.html")
    if os.path.exists(index_path):
        with open(index_path, "r", encoding="utf-8") as f:
            return HTMLResponse(f.read())
    return {"status": "Ragura backend running."}


@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    safe_name = f"{int(time.time())}_{uuid.uuid4().hex}_{file.filename}"
    path = os.path.join(UPLOAD_DIR, safe_name)

    content = await file.read()
    with open(path, "wb") as f:
        f.write(content)

    text = extract_text_from_file(path)

    uploads_index[safe_name] = {
        "original_name": file.filename,
        "path": path,
        "text": text,
        "uploaded_at": time.time()
    }

    # NEW — Add image OCR to image memory
    if file.filename.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tiff")):
        add_image(file.filename, text)

    # Add to RAG (unchanged)
    try:
        add_document(text, metadata={"source": file.filename})
    except Exception as e:
        return {"filename": file.filename, "chars": len(text), "embedding_error": str(e)}

    return {"filename": file.filename, "chars": len(text)}


@app.post("/chat")
async def chat(message: str = Form(...), model: str = Form(None), k: int = Form(3)):

    use_rag = should_use_rag(message)
    context = memory.recall(message)

    # NEW — Multi-image OCR retrieval
    image_context = ""
    images = get_images_for_query(message)
    if images:
        blocks = []
        for img in images:
            blocks.append(
                f"--- OCR extracted from {img['filename']} ---\n{img['text']}"
            )
        image_context = "\n\n".join(blocks)

    # RAG retrieval (unchanged)
    retrieved_text = ""
    retrieved_meta = []
    if use_rag:
        retrieved_docs = retrieve(message, k=k)
        if retrieved_docs:
            chunks = []
            for d, score in retrieved_docs:
                content = d.page_content
                meta = d.metadata
                src = meta.get("source", "<unknown>")
                chunks.append(f"--- from {src} ---\n{content}")
                retrieved_meta.append(meta)
            retrieved_text = "\n\n".join(chunks)

    print("========== DEBUG RAG OUTPUT ==========")
    print(f"RAG Used: {use_rag}")
    if not use_rag:
        print("RAG skipped due to generic message or short length")
    elif use_rag and retrieved_text:
        chunks = retrieved_text.split('\n\n')
        for i, chunk in enumerate(chunks):
            print(f"--- Chunk {i} ---")
            print(chunk[:500] + "..." if len(chunk) > 500 else chunk)
            print("-----------------------------------")
    else:
        print("No documents retrieved from RAG")
    print("=====================================")

    # PROMPT BUILDING (only small addition for images)
    if use_rag and retrieved_text:
        full_prompt = f"""
CONTEXT FROM PREVIOUS CONVERSATION:
{context}

{("EXTRACTED IMAGE TEXT:\n" + image_context) if image_context else ""}

[Retrieved Documents]
{retrieved_text}

User Question: {message}
Assistant:
"""
    else:
        full_prompt = f"""
{context}

{("EXTRACTED IMAGE TEXT:\n" + image_context) if image_context else ""}

User Question: {message}
Assistant:
"""

    resp = call_model(full_prompt, model_name=model)
    memory.add(message, resp)

    return {"response": resp, "retrieved": retrieved_meta}


@app.get("/list_uploads")
def list_uploads():
    out = []
    for k, v in uploads_index.items():
        out.append({"id": k, "name": v["original_name"], "chars": len(v["text"])})
    return out


@app.get("/download/{file_id}")
def download_file(file_id: str):
    rec = uploads_index.get(file_id)
    if not rec:
        return {"error": "not found"}
    return FileResponse(rec["path"], media_type="application/octet-stream", filename=rec["original_name"])


@app.post("/clear_uploads")
def clear_uploads():
    for k, v in list(uploads_index.items()):
        try:
            os.remove(v["path"])
        except:
            pass
        uploads_index.pop(k, None)
    #Clear image memory
    clear_image_memory()

    return {"message": "uploads cleared, RAG database preserved"}


@app.post("/export")
def export_response(text: str = Form(...), fmt: str = Form("txt")):
    name = f"ragura_response_{int(time.time())}"
    path = os.path.join(UPLOAD_DIR, f"{name}.{fmt}")

    try:
        if fmt == "txt":
            save_text_to_txt(text, path)
        elif fmt == "docx":
            save_text_to_docx(text, path)
        elif fmt == "pdf":
            save_text_to_pdf(text, path)
        else:
            return {"error": "unsupported format"}
        return FileResponse(path, filename=os.path.basename(path))
    except Exception as e:
        return {"error": str(e)}


@app.post("/clear_memory")
def clear_memory():
    memory.clear()
    return {"message": "memory cleared"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, reload=False)
