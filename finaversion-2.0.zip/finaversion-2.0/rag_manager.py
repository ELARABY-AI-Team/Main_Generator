import os
import threading
import math
import re
from typing import List
from langchain_ollama import OllamaEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from file_processing import extract_text_from_file, extract_text_with_preserved_structure


BASE_DIR = os.path.dirname(__file__)
CHROMA_DIR = os.path.join(BASE_DIR, "chroma_db")
os.makedirs(CHROMA_DIR, exist_ok=True)

OLLAMA_BASE_URL = "http://10.11.3.181:11434"
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "mxbai-embed-large")

embeddings = OllamaEmbeddings(model=EMBEDDING_MODEL, base_url=OLLAMA_BASE_URL)

# Single writer lock to avoid concurrent writes to Chroma (helps prevent DB corruption)
_chroma_write_lock = threading.Lock()

def get_vectorstore():
    """
    Return a Chroma vectorstore instance connected to the same persist dir.
    Keeps telemetry off to avoid some chromadb backfill issues.
    """
    return Chroma(persist_directory=CHROMA_DIR, embedding_function=embeddings)

# -------------------- Table normalizer (enhanced) --------------------
def _normalize_table_rows(text: str) -> str:
    """
    Enhanced table normalizer that preserves table structure for technical documents
    """
    lines = text.splitlines()
    out = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Detect table rows with pipe separators
        if "|" in line:
            cols = [c.strip() for c in line.split("|")]
            # remove empty edges caused by leading/trailing | split
            if cols and (cols[0] == "" or cols[-1] == ""):
                cols = cols[1:-1]
            # ensure we have at least two columns to consider it a table row
            if len(cols) >= 2:
                # Enhanced cleaning for technical table content
                cleaned_cols = []
                for col in cols:
                    # Fix common technical term errors in table cells
                    col = re.sub(r'\bSTM23F', 'STM32F', col)
                    col = re.sub(r'\bCortex\s*fi', 'Cortex', col)
                    col = re.sub(r'\bArm\s*fi', 'Arm', col)
                    cleaned_cols.append(col.strip())
                out.append("| " + " | ".join(cleaned_cols) + " |")
                continue
        
        # For non-table lines, apply technical term corrections
        line = re.sub(r'\bSTM23F', 'STM32F', line)
        line = re.sub(r'\bCortex\s*fi', 'Cortex', line)
        line = re.sub(r'\bArm\s*fi', 'Arm', line)
        line = re.sub(r'\bDecspiritno\b', 'Description', line)
        line = re.sub(r'\becnerefeR\b', 'Reference', line)
        line = re.sub(r'\breb mturnaP\b', 'Parameter', line)
        
        out.append(line)
    return "\n".join(out)

# -------------------- Enhanced chunking with structure preservation --------------------
def _chunk_by_lines_enhanced(text: str, lines_per_chunk: int) -> List[str]:
    """
    Enhanced line-based chunking that preserves table structure and technical content
    """
    if not text:
        return []
    
    lines = text.splitlines()
    chunks = []
    
    # First, group related lines (tables with their headers, etc.)
    grouped_lines = []
    i = 0
    while i < len(lines):
        current_line = lines[i]
        
        # If this line looks like a table header or start of table
        if current_line.count('|') >= 2 and i + 1 < len(lines) and lines[i + 1].count('|') >= 2:
            # Group table lines together
            table_group = [current_line]
            i += 1
            while i < len(lines) and lines[i].count('|') >= 2:
                table_group.append(lines[i])
                i += 1
            grouped_lines.append('\n'.join(table_group))
        else:
            # Regular text line
            grouped_lines.append(current_line)
            i += 1
    
    # Now chunk the grouped lines
    current_chunk = []
    current_line_count = 0
    
    for group in grouped_lines:
        group_lines = group.split('\n')
        group_line_count = len(group_lines)
        
        # If adding this group would exceed chunk size and we have some content already
        if current_line_count + group_line_count > lines_per_chunk and current_chunk:
            chunks.append('\n'.join(current_chunk))
            current_chunk = []
            current_line_count = 0
        
        # Add the group to current chunk
        if isinstance(group, list):
            current_chunk.extend(group)
        else:
            current_chunk.append(group)
        current_line_count += group_line_count
        
        # If current chunk is large enough, save it
        if current_line_count >= lines_per_chunk:
            chunks.append('\n'.join(current_chunk))
            current_chunk = []
            current_line_count = 0
    
    # Add any remaining content
    if current_chunk:
        chunks.append('\n'.join(current_chunk))
    
    return chunks

# -------------------- Add text directly (enhanced) --------------------
def add_document(text: str, metadata: dict = None, chunk_size: int = 1500, chunk_overlap: int = 200, normalize_tables: bool = True, batch_size: int = 64):
    """
    Enhanced document addition with better technical content handling
    """
    # 1) ensure UTF-8 safe string
    if isinstance(text, bytes):
        text = text.decode("utf-8", "replace")
    else:
        text = text.encode("utf-8", "replace").decode("utf-8")

    # 2) enhanced table normalization
    if normalize_tables:
        text = _normalize_table_rows(text)

    # 3) enhanced chunking with structure preservation
    chunks = _chunk_by_lines_enhanced(text, chunk_size)

    # 4) create Document objects with enhanced metadata
    enhanced_metadata = metadata.copy() if metadata else {}
    enhanced_metadata.update({
        "chunk_count": len(chunks),
        "processing_version": "enhanced_v2"
    })
    
    docs = [Document(page_content=chunk, metadata=enhanced_metadata) for chunk in chunks]

    # 5) enhanced batch processing with progress tracking
    db = get_vectorstore()
    with _chroma_write_lock:
        try:
            total_batches = math.ceil(len(docs) / batch_size)
            for i in range(0, len(docs), batch_size):
                batch = docs[i:i + batch_size]
                batch_num = (i // batch_size) + 1
                print(f"📦 Processing batch {batch_num}/{total_batches} ({len(batch)} chunks)")
                db.add_documents(batch)
            db.persist()
            print(f"✅ Successfully added {len(docs)} chunks to Chroma")
        except Exception as e:
            # Enhanced error recovery
            print(f"⚠️ Chroma add_documents error: {e} → retrying with smaller batches")
            try:
                for i in range(0, len(docs), 8):
                    db.add_documents(docs[i:i + 8])
                db.persist()
                print("✅ Recovery successful with smaller batches")
            except Exception as e2:
                print(f"‼️ Retry failed: {e2}")
                raise

# -------------------- Add large files safely (enhanced) --------------------
def add_document_from_file(file_path: str, chunk_size: int = 1500, chunk_overlap: int = 200, normalize_tables: bool = True, batch_size: int = 64, use_enhanced_extraction: bool = True):
    """
    Enhanced file processing with structure preservation and progress tracking
    """
    print(f"🔍 Processing {file_path}...")
    
    # Choose extraction method
    if use_enhanced_extraction:
        text = extract_text_with_preserved_structure(file_path)
        print("🔄 Using enhanced extraction with structure preservation")
    else:
        text = extract_text_from_file(file_path)
        print("🔄 Using standard extraction")
    
    if not text or text.strip() == "":
        print(f"❌ No text extracted from {file_path}")
        return False

    # Debug info
    lines = text.split('\n')
    print(f"📊 Extracted {len(lines)} lines, {len(text)} characters")
    
    # Show sample of content
    print("📄 Sample of extracted content (first 5 lines):")
    for i, line in enumerate(lines[:5]):
        print(f"   {i+1}: {line[:80]}{'...' if len(line) > 80 else ''}")
    
    if len(lines) > 5:
        print("   ...")

    # Use enhanced add_document
    metadata = {
        "source": os.path.basename(file_path),
        "file_path": file_path,
        "extraction_method": "enhanced" if use_enhanced_extraction else "standard"
    }
    
    add_document(text, metadata=metadata, chunk_size=chunk_size, chunk_overlap=chunk_overlap, normalize_tables=normalize_tables, batch_size=batch_size)
    print(f"✅ Successfully processed {file_path}")
    return True

# -------------------- Enhanced retrieval --------------------
def retrieve(query: str, k: int = 3, similarity_threshold: float = 0.6):
    """
    Retrieve top-k documents above a similarity threshold.
    Returns list of (Document, score) tuples.
    """
    if isinstance(query, bytes):
        query = query.decode("utf-8", "replace")
    else:
        query = query.encode("utf-8", "replace").decode("utf-8")

    # Fix common technical term errors in query
    query = re.sub(r'\bSTM23F', 'STM32F', query)
    query = re.sub(r'\bCortex\s*fi', 'Cortex', query)
    query = re.sub(r'\bArm\s*fi', 'Arm', query)

    db = get_vectorstore()

    # Get query embedding
    query_vec = embeddings.embed_query(query)

    # Get all docs and their embeddings
    all_docs = db.get(include=["embeddings", "metadatas", "documents"])
    filtered_docs = []

    for doc_text, meta, emb in zip(all_docs["documents"], all_docs["metadatas"], all_docs["embeddings"]):
        # Compute cosine similarity
        dot = sum(q*e for q, e in zip(query_vec, emb))
        norm_q = sum(q*q for q in query_vec) ** 0.5
        norm_e = sum(e*e for e in emb) ** 0.5
        sim = dot / (norm_q * norm_e + 1e-8)

        if sim >= similarity_threshold:
            filtered_docs.append((Document(page_content=doc_text, metadata=meta), sim))

    # Sort by similarity descending and return top-k
    filtered_docs.sort(key=lambda x: x[1], reverse=True)
    top_docs = filtered_docs[:k]

    print(f"✅ Retrieved {len(top_docs)}/{k} relevant chunks after similarity filter")
    return top_docs


# -------------------- Utility functions --------------------
def get_chroma_stats():
    """Get statistics about the Chroma database"""
    db = get_vectorstore()
    collection = db._collection
    if collection:
        count = collection.count()
        return {
            "total_chunks": count,
            "chroma_directory": CHROMA_DIR
        }
    return {"error": "Could not access collection"}

def clear_chroma_db():
    """Clear the Chroma database"""
    db = get_vectorstore()
    db.delete_collection()
    print("🗑️ Chroma database cleared")

# -------------------- Debug function --------------------
def debug_extraction(file_path: str):
    """Debug function to test extraction without saving to Chroma"""
    print(f"🔍 DEBUG: Testing extraction for {file_path}")
    
    # Test both extraction methods
    print("\n=== STANDARD EXTRACTION ===")
    standard_text = extract_text_from_file(file_path)
    standard_lines = standard_text.split('\n')
    print(f"Lines: {len(standard_lines)}, Chars: {len(standard_text)}")
    print("First 3 lines:")
    for i, line in enumerate(standard_lines[:3]):
        print(f"  {i+1}: {line}")
    
    print("\n=== ENHANCED EXTRACTION ===")
    enhanced_text = extract_text_with_preserved_structure(file_path)
    enhanced_lines = enhanced_text.split('\n')
    print(f"Lines: {len(enhanced_lines)}, Chars: {len(enhanced_text)}")
    print("First 3 lines:")
    for i, line in enumerate(enhanced_lines[:3]):
        print(f"  {i+1}: {line}")
    
    return {
        "standard": standard_text,
        "enhanced": enhanced_text
    }