import os
import docx
import pandas as pd
import xml.etree.ElementTree as ET
from PIL import Image, ImageFilter, ImageOps, ImageEnhance
import pytesseract
import pdfplumber
from pdf2image import convert_from_path
import re
from concurrent.futures import ThreadPoolExecutor
import logging
import sys
# Suppress noisy pdfminer/pdfplumber logs
logging.getLogger("pdfminer").setLevel(logging.ERROR)
logging.getLogger("pdfplumber").setLevel(logging.ERROR)


# === Paths for bundled Tesseract and Poppler ===
if getattr(sys, 'frozen', False):  # Running as EXE (PyInstaller)
    base_path = sys._MEIPASS       # PyInstaller temp folder
else:
    base_path = os.path.dirname(os.path.abspath(__file__))

# Paths inside your project/build
TESSERACT_PATH = os.path.join(base_path, "Tesseract-OCR", "tesseract.exe")
POPPLER_PATH   = os.path.join(base_path, "poppler", "Library", "bin")

# Apply paths
pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

# === DEBUG: Verify paths exist ===
print(f"[DEBUG] Tesseract path: {TESSERACT_PATH}  ->  Exists: {os.path.exists(TESSERACT_PATH)}")
print(f"[DEBUG] Poppler path:   {POPPLER_PATH}    ->  Exists: {os.path.exists(POPPLER_PATH)}")

# If you have TESSERACT or POPPLER installed in non-standard locations
#POPPLER_PATH = None
#pytesseract.pytesseract.tesseract_cmd = r"D:\AI Projects\Agent\server agent\Ragura_web_Agent\Tesseract-OCR\tesseract.exe"

# -------------------- Enhanced Helper functions --------------------
def enhanced_preprocess_for_technical_docs(pil_img: Image.Image):
    """Enhanced preprocessing specifically for technical documents"""
    img = pil_img.convert("RGB")
    img = ImageOps.exif_transpose(img)
    
    # More aggressive downscaling for better OCR
    max_dim = 2000
    if max(img.size) > max_dim:
        scale = max_dim / max(img.size)
        new_size = (int(img.width * scale), int(img.height * scale))
        img = img.resize(new_size, Image.LANCZOS)
    
    # Enhanced preprocessing pipeline
    img = ImageOps.grayscale(img)
    
    # More aggressive contrast enhancement for technical docs
    img = ImageEnhance.Contrast(img).enhance(2.0)
    img = ImageEnhance.Sharpness(img).enhance(1.5)
    
    # Additional noise reduction
    img = img.filter(ImageFilter.MedianFilter(size=5))
    img = img.filter(ImageFilter.SMOOTH)
    
    return img

def preprocess_image_for_ocr(pil_img: Image.Image):
    """Original preprocessing - kept for compatibility"""
    img = pil_img.convert("RGB")
    img = ImageOps.exif_transpose(img)
    max_dim = 3000
    if max(img.size) > max_dim:
        scale = max_dim / max(img.size)
        new_size = (int(img.width * scale), int(img.height * scale))
        img = img.resize(new_size, Image.LANCZOS)
    img = ImageOps.grayscale(img)
    img = ImageEnhance.Contrast(img).enhance(1.6)
    img = ImageEnhance.Sharpness(img).enhance(1.2)
    img = img.filter(ImageFilter.MedianFilter(size=3))
    return img

def clean_pdf_artifacts(text: str) -> str:
    """
    Remove unwanted PDF character codes like (cid:14), (cid:4), etc.
    Also normalize whitespace and force a UTF-8-clean string.
    """
    if not text:
        return ""
    # remove common cid artifacts
    text = re.sub(r"\(cid:\d+\)", "", text)
    # replace weird multiple dots
    text = re.sub(r"[ \t]+", " ", text)
    # normalize newlines (keep them)
    text = re.sub(r"\r\n?", "\n", text)
    # collapse multiple spaces but preserve newlines
    text = "\n".join(" ".join(line.split()) for line in text.splitlines())
    # ensure valid unicode (replace errors)
    if isinstance(text, bytes):
        try:
            text = text.decode("utf-8", "replace")
        except Exception:
            text = text.decode(errors="ignore")
    else:
        text = text.encode("utf-8", "replace").decode("utf-8")
    return text.strip()

def clean_technical_text(text: str) -> str:
    """Enhanced cleaning for technical document artifacts"""
    if not text:
        return ""
    
    # Fix common technical document issues
    replacements = [
        (r'ﬁ', 'fi'),
        (r'ﬂ', 'fl'),
        (r'([a-z])([A-Z])', r'\1 \2'),
        (r'\s+', ' '),
        (r'\.{2,}', '...'),
        (r'-\s*\n\s*', ''),
        # Fix common OCR errors in technical terms
        (r'\bSTM23F', 'STM32F'),
        (r'\bCortex\s*fi', 'Cortex'),
        (r'\bArm\s*fi', 'Arm'),
        (r'\bDecspiritno\b', 'Description'),
        (r'\becnerefeR\b', 'Reference'),
        (r'\breb mturnaP\b', 'Parameter'),
        (r'\bsoCnetnt\b', 'Contents'),
        (r'\bLiso tfat bles\b', 'List of tables'),
        (r'\bLiso tfif ugres\b', 'List of figures'),
    ]
    
    for pattern, replacement in replacements:
        text = re.sub(pattern, replacement, text)
    
    return text.strip()

def _is_text_garbled_enhanced(text: str) -> bool:
    """
    Enhanced heuristic to detect corrupted extracted text from PDFs.
    """
    if not text:
        return True

    # Check for common technical document corruption patterns
    corruption_indicators = [
        r"\(cid:\d+\)",
        r"[a-z][A-Z][a-z]",  # Mixed case within words
        r"\b[a-z]{1,2}[0-9]+\b",  # Letters followed by numbers
        r"\b[0-9]+[a-z]{1,2}\b",  # Numbers followed by letters
        r"\b[a-zA-Z]{15,}\b",  # Very long words
        r'\bSTM23F',  # Common STM32 error
        r'\bCortex\s*fi',  # Common Cortex error
    ]
    
    for pattern in corruption_indicators:
        if re.search(pattern, text):
            return True

    # Check character diversity
    if len(text) > 100:
        alpha_ratio = sum(1 for c in text if c.isalpha()) / len(text)
        space_ratio = sum(1 for c in text if c.isspace()) / len(text)
        
        if alpha_ratio < 0.3 or space_ratio < 0.05:
            return True

    # Original checks
    if re.search(r"\(cid:\d+\)", text):
        return True

    total = len(text)
    if total == 0:
        return True
    printable = sum(1 for ch in text if 32 <= ord(ch) <= 126)
    printable_ratio = printable / total
    if printable_ratio < 0.6:
        return True

    words = re.findall(r"[A-Za-z]{2,}", text)
    word_count = len(words)
    if word_count == 0:
        return True
    english_like = sum(1 for w in words if re.match(r"^[A-Za-z]{2,}$", w))
    if english_like / max(1, word_count) < 0.4:
        return True

    return False

def _is_text_garbled(text: str) -> bool:
    """Use enhanced detection"""
    return _is_text_garbled_enhanced(text)

def extract_tables_enhanced(pdf_path: str) -> str:
    """Enhanced table extraction with better formatting"""
    table_content = ""
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page_num, page in enumerate(pdf.pages):
                tables = page.extract_tables()
                if tables:
                    table_content += f"\n--- Page {page_num + 1} Tables ---\n"
                    for table_num, table in enumerate(tables):
                        table_content += f"Table {table_num + 1}:\n"
                        for row in table:
                            # Clean and filter cells
                            clean_row = []
                            for cell in row:
                                if cell and str(cell).strip():
                                    clean_cell = str(cell).strip()
                                    # Remove common table artifacts
                                    clean_cell = re.sub(r'\(cid:\d+\)', '', clean_cell)
                                    clean_cell = re.sub(r'\s+', ' ', clean_cell)
                                    clean_row.append(clean_cell)
                                else:
                                    clean_row.append("")
                            
                            # Only add non-empty rows
                            if any(clean_row):
                                table_content += " | ".join(clean_row) + "\n"
                        table_content += "\n"
    except Exception as e:
        print(f"Enhanced table extraction error: {e}")
    
    return clean_technical_text(table_content)

def extract_text_with_tables_improved(file_path: str) -> str:
    """Improved text extraction with better table handling"""
    text_content = ""
    table_content = ""
    
    # First extract tables separately
    table_content = extract_tables_enhanced(file_path)
    
    # Then extract regular text
    try:
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                # Extract text with better settings
                text = page.extract_text(layout=True, x_tolerance=2, y_tolerance=2)
                if text:
                    text_content += clean_pdf_artifacts(text) + "\n"
    except Exception as e:
        print(f"pdfplumber text extraction failed: {e}")
    
    # Combine text and tables
    combined_content = text_content + "\n" + table_content
    
    # Check if we need OCR
    if _is_text_garbled(combined_content) or len(combined_content.strip()) < 500:
        print("Text quality poor, using enhanced OCR...")
        try:
            images = convert_from_path(
                file_path, 
                dpi=300,
                poppler_path=POPPLER_PATH if POPPLER_PATH and os.path.exists(POPPLER_PATH) else None
            )
            ocr_text = ""
            for img in images:
                processed_img = enhanced_preprocess_for_technical_docs(img)
                # Better OCR settings for technical documents
                custom_config = r'--oem 3 --psm 6 -c preserve_interword_spaces=1'
                page_text = pytesseract.image_to_string(processed_img, config=custom_config)
                ocr_text += clean_pdf_artifacts(page_text) + "\n"
            combined_content = clean_technical_text(ocr_text)
        except Exception as e:
            print(f"Enhanced OCR failed: {e}")
    
    return combined_content

def extract_text_with_preserved_structure(file_path: str) -> str:
    """
    Extract text while preserving line breaks and table structure for RAG chunking
    """
    file_ext = os.path.splitext(file_path)[1].lower()
    
    if file_ext == '.pdf':
        # Use the improved extraction but ensure line breaks are preserved
        text_content = ""
        
        # Try PyMuPDF first for better structure preservation
        try:
            import fitz
            doc = fitz.open(file_path)
            for page in doc:
                # Extract text with layout preservation
                text = page.get_text("text", sort=True)
                # Also get text by blocks for better structure
                blocks = page.get_text("dict")["blocks"]
                for block in blocks:
                    if "lines" in block:
                        for line in block["lines"]:
                            line_text = ""
                            for span in line["spans"]:
                                line_text += span["text"] + " "
                            text_content += line_text.strip() + "\n"
                        text_content += "\n"  # Add space between blocks
                text_content += "\n"  # Add space between pages
            doc.close()
            
            # Add enhanced table extraction
            table_content = extract_tables_enhanced(file_path)
            text_content += "\n" + table_content
            
        except Exception as e:
            print(f"PyMuPDF structure extraction failed: {e}")
            # Fallback to basic extraction
            text_content = extract_text_with_tables_improved(file_path)
    else:
        # Use existing extraction for other file types
        text_content = extract_text_with_tables_improved(file_path)
    
    # Enhanced cleaning that preserves structure
    text_content = clean_pdf_artifacts(text_content)
    
    # Additional cleaning for technical docs while preserving line breaks
    lines = text_content.split('\n')
    cleaned_lines = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Fix common OCR errors but preserve table markers
        replacements = [
            (r'ﬁ', 'fi'),
            (r'ﬂ', 'fl'),
            (r'\bSTM23F', 'STM32F'),
            (r'\bCortex\s*fi', 'Cortex'),
            (r'\bArm\s*fi', 'Arm'),
            (r'\bDecspiritno\b', 'Description'),
            (r'\becnerefeR\b', 'Reference'),
            (r'\breb mturnaP\b', 'Parameter'),
        ]
        
        for pattern, replacement in replacements:
            line = re.sub(pattern, replacement, line)
            
        cleaned_lines.append(line)
    
    return '\n'.join(cleaned_lines)

# -------------------- Main extraction function --------------------
def extract_text_from_file(file_path: str) -> str:
    """
    Supported: .pdf, .docx, images, .svg, .vsdx, .xlsx/.xls, text files.
    For PDFs: uses improved extraction with better table handling.
    """
    file_ext = os.path.splitext(file_path)[1].lower()
    text_content = ""
    try:
        if file_ext == '.pdf':
            # Use improved extraction with better table handling
            text_content = extract_text_with_preserved_structure(file_path)
            
            # Final fallback if everything fails
            if not text_content.strip() or len(text_content.strip()) < 100:
                print("All methods failed, using basic OCR...")
                imgs = convert_from_path(
                    file_path,
                    poppler_path=POPPLER_PATH if POPPLER_PATH and os.path.exists(POPPLER_PATH) else None,
                    dpi=200
                )
                for img in imgs:
                    try:
                        img = preprocess_image_for_ocr(img)
                        text_content += pytesseract.image_to_string(img) + "\n"
                    except Exception:
                        continue
                text_content = clean_technical_text(text_content)

        elif file_ext in ['.docx']:
            doc = docx.Document(file_path)
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            text_content = "\n".join(paragraphs)
            for table in doc.tables:
                for row in table.rows:
                    text_content += "\n" + " | ".join([cell.text.strip() for cell in row.cells])

        elif file_ext in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
            img = Image.open(file_path)
            img = enhanced_preprocess_for_technical_docs(img)
            text_content = pytesseract.image_to_string(img)
            text_content = clean_technical_text(text_content)

        elif file_ext == '.svg':
            try:
                tree = ET.parse(file_path)
                root = tree.getroot()
                texts = [elem.text.strip() for elem in root.iter() if elem.text and elem.text.strip()]
                text_content = "\n".join(texts)
            except Exception:
                text_content = ""

        elif file_ext == '.vsdx':
            try:
                from vsdx import VisioFile
                vf = VisioFile(file_path)
                texts = []
                for page in vf.pages:
                    for shape in page.shapes:
                        if getattr(shape, "text", None):
                            texts.append(shape.text.strip())
                text_content = "\n".join(texts)
            except Exception:
                text_content = ""

        elif file_ext in ['.xlsx', '.xls']:
            try:
                xls = pd.ExcelFile(file_path, engine='openpyxl')
                text_rows = []
                for sheet_name in xls.sheet_names:
                    df = pd.read_excel(file_path, sheet_name=sheet_name, dtype=str, engine='openpyxl')
                    text_rows.append(f"--- Sheet: {sheet_name} ---")
                    for row in df.values:
                        text_rows.append(" | ".join([str(cell) for cell in row if pd.notna(cell)]))
                text_content = "\n".join(text_rows)
            except Exception as e1:
                try:
                    import xlwings as xw
                    wb = xw.Book(file_path)
                    text_rows = []
                    for sheet in wb.sheets:
                        text_rows.append(f"--- Sheet: {sheet.name} ---")
                        data = sheet.used_range.value
                        if data:
                            for row in data:
                                text_rows.append(" | ".join([str(cell) for cell in row if cell is not None]))
                    wb.close()
                    text_content = "\n".join(text_rows)
                except Exception as e2:
                    text_content = f"❌ Error reading Excel: pandas error: {e1}; xlwings fallback error: {e2}"

        else:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                text_content = f.read()

    except Exception as e:
        return f"❌ Error reading {file_path}: {str(e)}"

    # Final cleaning
    text_content = clean_pdf_artifacts(text_content)
    text_content = clean_technical_text(text_content)
    
    # Ensure proper line structure for RAG chunking
    lines = text_content.split('\n')
    structured_lines = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # If line looks like a table row (contains multiple | characters)
        if line.count('|') >= 2:
            # Clean up the table row but keep the structure
            cells = [cell.strip() for cell in line.split('|') if cell.strip()]
            if len(cells) >= 2:
                structured_lines.append(' | '.join(cells))
                continue
        
        # For regular text, just add the cleaned line
        structured_lines.append(line)
    
    return '\n'.join(structured_lines)