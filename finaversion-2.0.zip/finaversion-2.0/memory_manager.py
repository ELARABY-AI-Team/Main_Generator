# backend/memory_manager.py
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class MemoryManager:
    def __init__(self):
        self.memory = []
        self.vectorizer = TfidfVectorizer()

    def add(self, user_input, model_output):
        self.memory.append(f"User: {user_input}\nAssistant: {model_output}")

    def recall(self, query, top_k=3):
        if not self.memory:
            return ""
        try:
            docs = self.memory + [query]
            vectors = self.vectorizer.fit_transform(docs)
            similarities = cosine_similarity(vectors[-1:], vectors[:-1]).flatten()
            top_indices = similarities.argsort()[-top_k:][::-1]
            return "\n\n".join([self.memory[i] for i in top_indices])
        except Exception:
            return ""

    def clear(self):
        self.memory = []
