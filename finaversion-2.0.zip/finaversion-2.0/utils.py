# backend/utils.py
import os
import docx
from docx.shared import Pt
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.units import mm
import textwrap
import re

# Optional Arabic/RTL support
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    RTL_SUPPORT = True
except ImportError:
    RTL_SUPPORT = False

# Font path (must exist)
FONT_PATH = os.path.join("C:\Windows\Fonts\Arial.ttf")

# PDF layout constants
PAGE_WIDTH, PAGE_HEIGHT = letter
LEFT_MARGIN = 20 * mm
RIGHT_MARGIN = 20 * mm
TOP_MARGIN = 20 * mm
BOTTOM_MARGIN = 20 * mm
FONT_SIZE = 12
LINE_SPACING = 14

# ================== CLEANUP ==================
def clean_ai_output(text: str) -> str:
    """
    Remove unwanted AI artifacts:
    - # or ## at start of lines
    - Markdown bold (**bold**) or italic (*italic*)
    - Extra empty lines
    """
    # Remove hash symbols at start of lines
    text = re.sub(r'^#+\s*', '', text, flags=re.MULTILINE)
    
    # Remove markdown bold and italic
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # **bold**
    text = re.sub(r'\*(.*?)\*', r'\1', text)      # *italic*

    # Remove trailing whitespace on lines
    text = '\n'.join(line.rstrip() for line in text.splitlines())
    
    # Remove multiple consecutive empty lines
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    return text

# ================== TXT ==================
def save_text_to_txt(text: str, path: str):
    """Save text in UTF-8 (works for any language)"""
    text = clean_ai_output(text)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path

# ================== DOCX ==================
def save_text_to_docx(text: str, path: str):
    """Save text in DOCX supporting Arabic and English"""
    text = clean_ai_output(text)
    d = docx.Document()
    style = d.styles['Normal']
    font = style.font
    font.name = 'Arial'
    font.size = Pt(FONT_SIZE)

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue

        # Reshape Arabic if RTL_SUPPORT is enabled
        display_text = line
        if RTL_SUPPORT and any("\u0600" <= c <= "\u06FF" for c in line):
            try:
                reshaped = arabic_reshaper.reshape(line)
                display_text = get_display(reshaped)
            except Exception:
                display_text = line

        p = d.add_paragraph(display_text)

        # Align paragraph
        if RTL_SUPPORT and any("\u0600" <= c <= "\u06FF" for c in line):
            p.alignment = docx.enum.text.WD_PARAGRAPH_ALIGNMENT.RIGHT
        else:
            p.alignment = docx.enum.text.WD_PARAGRAPH_ALIGNMENT.LEFT

        # Apply font to all runs
        for run in p.runs:
            run.font.name = 'Arial'
            run.font.size = Pt(FONT_SIZE)

    d.save(path)
    return path

# ================== PDF ==================
def save_text_to_pdf(text: str, path: str):
    """Save text to PDF supporting all languages and RTL text"""
    text = clean_ai_output(text)
    if not os.path.exists(FONT_PATH):
        raise FileNotFoundError(f"Font not found: {FONT_PATH}")

    pdfmetrics.registerFont(TTFont('CustomFont', FONT_PATH))
    c = canvas.Canvas(path, pagesize=letter)
    c.setFont("CustomFont", FONT_SIZE)

    y = PAGE_HEIGHT - TOP_MARGIN
    text_width = PAGE_WIDTH - LEFT_MARGIN - RIGHT_MARGIN
    wrapper = textwrap.TextWrapper(width=80)  # adjust width as needed

    for paragraph in text.splitlines():
        paragraph = paragraph.strip()
        if not paragraph:
            continue

        # Detect if paragraph contains Arabic characters
        is_arabic = any("\u0600" <= c <= "\u06FF" for c in paragraph)

        display_text = paragraph

        # Apply RTL reshaping only if Arabic
        if RTL_SUPPORT and is_arabic:
            try:
                reshaped = arabic_reshaper.reshape(paragraph)
                display_text = get_display(reshaped)
            except Exception:
                display_text = paragraph

        # Wrap long lines
        lines = wrapper.wrap(display_text)

        for line in lines:
            # Alignment
            if RTL_SUPPORT and is_arabic:
                # Right-align for Arabic
                text_width_line = c.stringWidth(line, "CustomFont", FONT_SIZE)
                x = PAGE_WIDTH - RIGHT_MARGIN - text_width_line
            else:
                # Left-align for English/other
                x = LEFT_MARGIN

            c.drawString(x, y, line)
            y -= LINE_SPACING

            # Page break
            if y < BOTTOM_MARGIN:
                c.showPage()
                c.setFont("CustomFont", FONT_SIZE)
                y = PAGE_HEIGHT - TOP_MARGIN

    c.save()
    return path
