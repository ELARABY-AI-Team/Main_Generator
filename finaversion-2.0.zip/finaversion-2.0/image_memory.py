# image_memory.py

import time

# Internal memory storage for images
_image_memory = []   # each entry: {filename, text, uploaded_at}


def add_image(filename: str, text: str):
    """
    Add an image (OCR-extracted text) to memory.
    Called from app.py after upload and OCR.
    """
    _image_memory.append({
        "filename": filename,
        "text": text,
        "uploaded_at": time.time()
    })


def get_all_images():
    """Return every stored image memory"""
    return list(_image_memory)


def find_images_in_message(message: str):
    """
    Return images if the message includes their filenames.
    Example:
        message = "explain engine.png"
    """
    msg = message.lower()
    return [img for img in _image_memory if img["filename"].lower() in msg]


def get_images_for_query(message: str):
    """
    Logic for deciding which images to return for a user's chat message:

    - If the user asks about images AND mentions specific filenames → return only those
    - If the user asks about images without specifics → return all images
    - Otherwise → return empty list
    """
    message_lower = message.lower()

    # User explicitly mentioned filenames?
    specific = find_images_in_message(message)
    if specific:
        return specific

    # User refers to images in general?
    keywords = ["image", "images", "photo", "picture", "pic"]
    if any(k in message_lower for k in keywords):
        return _image_memory

    # No image requested
    return []

def clear_image_memory():
    """Remove ALL stored images from memory"""
    _image_memory.clear()
    print("memory cleared")
