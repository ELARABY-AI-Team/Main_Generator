import os
from langchain_ollama import OllamaEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from file_processing import extract_text_from_file

BASE_DIR = os.path.dirname(__file__)
CHROMA_DIR = os.path.join(BASE_DIR, "chroma_db")
os.makedirs(CHROMA_DIR, exist_ok=True)

OLLAMA_BASE_URL = "http://10.11.3.181:11434"
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "mxbai-embed-large")

embeddings = OllamaEmbeddings(model=EMBEDDING_MODEL, base_url=OLLAMA_BASE_URL)

def get_vectorstore():
    return Chroma(persist_directory=CHROMA_DIR, embedding_function=embeddings)

# -------------------- Add text directly --------------------
def add_document(text: str, metadata: dict = None, chunk_size: int = 1500, chunk_overlap: int = 200):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n", " ", ""]
    )
    docs = splitter.create_documents([text], metadatas=[metadata or {}])
    db = get_vectorstore()
    db.add_documents(docs)
    db.persist()

# -------------------- Add large files safely --------------------
def add_document_from_file(file_path: str, chunk_size: int = 1500, chunk_overlap: int = 200):
    text = extract_text_from_file(file_path)
    if not text:
        print(f"❌ No text extracted from {file_path}")
        return

    lines = text.split("\n")
    docs = []
    for i in range(0, len(lines), chunk_size):
        chunk_text = "\n".join(lines[i:i+chunk_size])
        docs.append(Document(page_content=chunk_text, metadata={"source": os.path.basename(file_path)}))

    db = get_vectorstore()
    db.add_documents(docs)
    db.persist()
    print(f"✅ Added {file_path} in {len(docs)} chunks")

# -------------------- Retrieve top-k --------------------
def retrieve(query: str, k: int = 3):
    db = get_vectorstore()
    retriever = db.as_retriever(search_kwargs={"k": k})
    docs = retriever._get_relevant_documents(query, run_manager=None)
    return docs
