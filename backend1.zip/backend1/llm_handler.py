# backend/llm_handler.py
import os
from langchain_ollama import OllamaLLM

# Set Ollama base URL (remote server)
OLLAMA_BASE_URL = "http://10.11.3.181:11434"

# Map UI names to actual Ollama models
MODEL_MAP = {
    "deepseek-70b": "deepseek-r1:70b",
    "deepseek-coder-33b": "deepseek-coder:33b",
    "qwen3": "Qwen3",
}

def call_model(prompt: str, model_name: str = None):
    """
    Calls an Ollama model using .invoke() ONLY.
    This avoids the 'OllamaLLM object is not callable' error.
    """

    # Resolve model name
    model = MODEL_MAP.get(model_name, MODEL_MAP["deepseek-70b"])

    try:
        # Initialize LLM
        llm = OllamaLLM(
            model=model,
            base_url=OLLAMA_BASE_URL,
            temperature=0.3,
        )

        # The ONLY correct way to call Ollama in LangChain
        result = llm.invoke(prompt)

        # Always a string
        return result.strip()

    except Exception as e:
        return f"❌ LLM error: {str(e)}"
