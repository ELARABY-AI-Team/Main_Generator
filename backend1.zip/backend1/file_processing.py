import os
import docx
import pandas as pd
import xml.etree.ElementTree as ET
from PIL import Image, ImageFilter, ImageOps, ImageEnhance
import pytesseract
import pdfplumber
from pdf2image import convert_from_path
import re
from concurrent.futures import ThreadPoolExecutor

# If you have TESSERACT or POPPLER installed in non-standard locations
POPPLER_PATH = None
pytesseract.pytesseract.tesseract_cmd = r"D:\AI Projects\Agent\server agent\Ragura_web_Agent\Tesseract-OCR"

# -------------------- Helper functions --------------------
def preprocess_image_for_ocr(pil_img: Image.Image):
    img = pil_img.convert("RGB")
    img = ImageOps.exif_transpose(img)
    img = ImageOps.grayscale(img)
    img = ImageEnhance.Contrast(img).enhance(1.6)
    img = ImageEnhance.Sharpness(img).enhance(1.2)
    img = img.filter(ImageFilter.MedianFilter(size=3))
    return img

def clean_pdf_artifacts(text: str) -> str:
    """
    Remove unwanted PDF character codes like (cid:14), (cid:4), etc.
    Also normalize whitespace.
    """
    text = re.sub(r"\(cid:\d+\)", "", text)
    text = " ".join(text.split())
    return text

# -------------------- Main extraction function --------------------
def extract_text_from_file(file_path: str) -> str:
    file_ext = os.path.splitext(file_path)[1].lower()
    text_content = ""
    try:
        if file_ext == '.pdf':
            with pdfplumber.open(file_path) as pdf:

                # ------------------ process a single page ------------------
                def process_page(page):
                    page_text = ""
                    # Extract tables first
                    tables = page.extract_tables()
                    if tables:
                        for table in tables:
                            for row in table:
                                page_text += " | ".join([str(cell).strip() if cell else "" for cell in row]) + "\n"
                    # Then extract normal text
                    page_text += (page.extract_text() or "") + "\n"
                    return page_text

                # ------------------ parallel processing ------------------
                with ThreadPoolExecutor(max_workers=4) as executor:
                    results = list(executor.map(process_page, pdf.pages))
                text_content = "\n".join(results)

                # Fallback to OCR if text is still empty
                if not text_content.strip():
                    imgs = convert_from_path(
                        file_path,
                        poppler_path=POPPLER_PATH if POPPLER_PATH and os.path.exists(POPPLER_PATH) else None
                    )
                    for img in imgs:
                        img = preprocess_image_for_ocr(img)
                        text_content += pytesseract.image_to_string(img)

        elif file_ext in ['.docx']:
            doc = docx.Document(file_path)
            # Extract paragraphs
            text_content = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
            # Extract tables
            for table in doc.tables:
                for row in table.rows:
                    text_content += "\n" + " | ".join([cell.text.strip() for cell in row.cells])

        elif file_ext in ['.png', '.jpg', '.jpeg', '.tiff', '.bmp']:
            img = Image.open(file_path)
            img = preprocess_image_for_ocr(img)
            text_content = pytesseract.image_to_string(img)

        elif file_ext == '.svg':
            tree = ET.parse(file_path)
            root = tree.getroot()
            texts = [elem.text.strip() for elem in root.iter() if elem.text and elem.text.strip()]
            text_content = "\n".join(texts)

        elif file_ext == '.vsdx':
            try:
                from vsdx import VisioFile
                vf = VisioFile(file_path)
                texts = []
                for page in vf.pages:
                    for shape in page.shapes:
                        if getattr(shape, "text", None):
                            texts.append(shape.text.strip())
                text_content = "\n".join(texts)
            except Exception:
                text_content = ""

        elif file_ext in ['.xlsx', '.xls']:
            try:
                xls = pd.ExcelFile(file_path, engine='openpyxl')
                text_rows = []
                for sheet_name in xls.sheet_names:
                    df = pd.read_excel(file_path, sheet_name=sheet_name, dtype=str, engine='openpyxl')
                    text_rows.append(f"--- Sheet: {sheet_name} ---")
                    for row in df.values:
                        text_rows.append(" | ".join([str(cell) for cell in row if pd.notna(cell)]))
                text_content = "\n".join(text_rows)
            except Exception as e1:
                try:
                    import xlwings as xw
                    wb = xw.Book(file_path)
                    text_rows = []
                    for sheet in wb.sheets:
                        text_rows.append(f"--- Sheet: {sheet.name} ---")
                        data = sheet.used_range.value
                        if data:
                            for row in data:
                                text_rows.append(" | ".join([str(cell) for cell in row if cell is not None]))
                    wb.close()
                    text_content = "\n".join(text_rows)
                except Exception as e2:
                    text_content = f"❌ Error reading Excel: pandas error: {e1}; xlwings fallback error: {e2}"

        else:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                text_content = f.read()

    except Exception as e:
        return f"❌ Error reading {file_path}: {str(e)}"

    # Clean text before returning
    text_content = clean_pdf_artifacts(text_content)
    return text_content.strip()
