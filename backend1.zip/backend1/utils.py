# backend/utils.py
import docx
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

def save_text_to_txt(text: str, path: str):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path

def save_text_to_docx(text: str, path: str):
    d = docx.Document()
    for line in text.splitlines():
        d.add_paragraph(line)
    d.save(path)
    return path

def save_text_to_pdf(text: str, path: str):
    c = canvas.Canvas(path, pagesize=letter)
    width, height = letter
    y = height - 40
    text_object = c.beginText(40, y)
    text_object.setFont("Helvetica", 10)
    for line in text.splitlines():
        text_object.textLine(line)
        y -= 12
        if y < 40:
            c.drawText(text_object)
            c.showPage()
            text_object = c.beginText(40, height - 40)
            text_object.setFont("Helvetica", 10)
            y = height - 40
    c.drawText(text_object)
    c.save()
    return path
