from rag_manager import get_vectorstore 

db = get_vectorstore()

data = db.get(include=["documents", "metadatas"])

docs = data["documents"]
metas = data["metadatas"]

print(f"Total docs in Chroma: {len(docs)}")

for i, (content, meta) in enumerate(zip(docs, metas)):
    source = meta.get("source", "<unknown>")
    preview = content[:120].replace("\n", " ")
    print(f"Doc {i}: {source} | {preview}...")
