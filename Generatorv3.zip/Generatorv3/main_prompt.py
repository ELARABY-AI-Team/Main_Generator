from datetime import datetime

def main_prompt(mcu_name):
    current_date = datetime.now().strftime("%Y-%m-%d")

    return f"""You are an embedded C engineer.
Given only the name of a microcontroller, generate a minimal and clean `main.h` file that includes only the most important and commonly used elements in embedded projects for that chip using MISRA C standard.

The header file of the Device name {mcu_name} should include:

1. A clean professional comment block at the top with:
   - File name
   - Short description
   - Author: Technology Inovation Software Team 
   - Device name {mcu_name}
   - Creation date: {current_date}
   - Standard: MISRA C
   - Copyright: ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP

2. Include directives:
   - MCU-specific include: `#include <.h>` or as appropriate for the MCU

3. Include the following standard C headers exactly as shown below, in this order:
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <inttypes.h>
#include <iso646.h>
#include <limits.h>
#include <math.h>
#include <setjmp.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

4. Useful typedefs:
   - `tbyte` for `uint8_t`
   - `tword` for `uint16_t`
   - `tlong` for `uint32_t`

5. Core macros:
   - SET_BIT(reg, bit)
   - CLR_BIT(reg, bit)
   - GET_BIT(reg, bit)
   - TOG_BIT(reg, bit)
   - If available: macros like DI(), EI(), Global_Int_Disable(), Global_Int_Enable(), HALT(), NOP() — use () because they are functions

6. SAFEGUARD MACROS — IMPORTANT:
   - You must **generate fully implemented versions** of the following two macros:
     - `GPIO_SAFEGUARD_Init()` → Should configure the actual GPIO (Data or value or logic)= 0 for all ports then Should configure the actual GPIO (Control or mode or Direction) = input for all ports, Disable all (pull high or pull up resistors) for all ports if exists, Disable all (woke up) registers for all ports if exists
     - `Registers_SAFEGUARD_Init()` → should Disable global intrupt register if exists, should Disable all Timers if exists,should Disable pulse width modulation (pwm) if exists, should Disable watchdog timer (wdt) if exists, should Disable input capture unit (ICU) if exists, should Disable Analog to digital converter (ADC) if exists, should Disable UART if exists, should Disable I2C if exists, should Disable SPI communication if exists, configure all GPIOS as an input/output pins (I/O)not special function registers like(ADC or UART)
   - DO NOT leave the implementation to the user.
   - Use **real registers and values** based on the given microcontroller. Avoid writing comments like "User: add implementation".
"""
