/**
 * @file config.h
 * @brief Configuration header file for the RENESAS_R5F11BBC microcontroller.
 *
 * This file provides declarations and definitions necessary for the
 * system configuration functions implemented in config.c.
 * It includes the main microcontroller header and defines return codes
 * and optional features for the configuration module.
 *
 * This header assumes that RENESAS_R5F11BBC_MAIN.h has already been generated
 * and contains necessary MCU-specific includes, typedefs (tbyte, tword, tlong),
 * bit manipulation macros (SET_BIT, etc.), and safeguard macros
 * (GPIO_SAFEGUARD_Init, Registers_SAFEGUARD_Init).
 */

#ifndef CONFIG_H_
#define CONFIG_H_

// --- Includes ---

/**
 * @brief Include the main microcontroller header.
 *        This header is expected to provide core MCU definitions,
 *        typedefs, and macros like tbyte, tword, tlong, SET_BIT,
 *        GPIO_SAFEGUARD_Init, Registers_SAFEGUARD_Init, etc.
 */
#include "RENESAS_R5F11BBC_MAIN.h"

// --- C++ Compatibility ---

#ifdef __cplusplus
extern "C" {
#endif

// --- Function Declarations ---

/**
 * @brief Initializes the microcontroller's essential peripherals and system settings.
 *        This typically includes clock configuration, GPIO pin initial states,
 *        Watchdog Timer setup (if enabled), and potentially other core modules.
 */
void mcu_config_Init(void);

/**
 * @brief Resets or 'pets' the Watchdog Timer (WDT).
 *        This function should be called periodically within the main application loop
 *        to prevent the WDT from timing out and resetting the system.
 *        Its implementation depends on the WDT configuration (if ENABLE_WATCHDOG is defined).
 */
void WDI_Reset(void);

// --- Optional Feature Configuration ---

/**
 * @brief Define this macro to enable the Watchdog Timer (WDT) functionality.
 *        If defined, mcu_config_Init() should configure the WDT,
 *        and WDI_Reset() should contain the necessary code to reset it.
 *        If commented out, WDT features are disabled, and WDI_Reset()
 *        might be an empty function or a placeholder.
 */
#define ENABLE_WATCHDOG

// --- Configuration Return/Error Codes ---

/**
 * @brief Configuration successful.
 */
#define CONFIG_OK       0

/**
 * @brief Configuration failed (e.g., invalid parameter, hardware error).
 */
#define CONFIG_FAIL     -1

// --- Extern Declarations (if needed) ---
// Add any 'extern' declarations for global configuration state variables
// or status flags defined in config.c here. Example:
// extern tbyte config_status_g;

#ifdef __cplusplus
}
#endif

#endif /* CONFIG_H_ */