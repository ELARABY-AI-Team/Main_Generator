#ifndef FAN_H
#define FAN_H

#include "MCAL.h"
#include "fan_user.h"
#include "tt_scheduler.h" // Include the chosen scheduler

// Include necessary HALs (adapted implicitly to use MCAL.h types)
#include "HAL_BUZZER.h"
#include "IR.h"
#include "HAL_PB.h"
#include "HAL_SSD.h"
#include "keypad.h"
#include "ntc.h"
#include "Stepper_motor.h"
#include "Touch_Pad.h"

/**
 * @brief Enum for fan operating states.
 */
typedef enum
{
    FAN_STATE_OFF = 0,
    FAN_STATE_LOW,
    FAN_STATE_MEDIUM,
    FAN_STATE_HIGH,
    FAN_STATE_ICE,
    FAN_STATE_MAX
} Fan_State_t;

/**
 * @brief Initializes the fan application middleware.
 *        This includes MCU configuration, HALs, and the scheduler.
 */
void fan_init(void);

/**
 * @brief The main loop for the fan application.
 *        This function should be called repeatedly in `main()`.
 */
void fan_main_loop(void);

/**
 * @brief Timer ISR handler for the scheduler tick.
 *        Assigned to TIM2_IRQHandler.
 */
void TIM2_IRQHandler(void);

/**
 * @brief Initializes the Interval Timer for the scheduler.
 * @param clock_source The clock source (unused in this specific MCAL implementation).
 * @param Tick_Time_ms The desired tick time in milliseconds.
 */
void Interval_Timer_Init(void* clock_source, t_Tick_Time Tick_Time_ms);

/**
 * @brief Sets the ISR callback for the Interval Timer.
 * @param callback Pointer to the function to be called by the timer ISR.
 */
void Interval_Timer_ISR_Callback(void (*callback)(void));

/**
 * @brief Enables the Interval Timer.
 */
void Interval_Timer_Enable(void);

#endif // FAN_H
