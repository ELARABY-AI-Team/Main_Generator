#ifndef FAN_USER_H
#define FAN_USER_H

#include "MCAL.h" // For t_port, t_pin types

// ==============================================================================
// 1. Scheduler Configuration
// ==============================================================================
#define FAN_SCHEDULER_TICK_MS           (5) // Scheduler tick in milliseconds

// Timer channel used for the scheduler tick (e.g., TIM2)
#define TIMER_SCHEDULER_CHANNEL         timer_channel_2

// ==============================================================================
// 2. Application Task Periods (in milliseconds)
//    These are then converted to scheduler ticks by dividing by FAN_SCHEDULER_TICK_MS
// ==============================================================================
#define FAN_NTC_UPDATE_PERIOD_MS        (500)
#define FAN_SSD_UPDATE_PERIOD_MS        (5)   // SSD_Update is recommended every 5ms
#define FAN_PB_UPDATE_PERIOD_MS         (10)
#define FAN_TOUCH_PAD_UPDATE_PERIOD_MS  (10)
#define FAN_KEYPAD_UPDATE_PERIOD_MS     (10)
#define FAN_BUZZER_UPDATE_PERIOD_MS     (25)  // From HAL_BUZZER.h
#define FAN_STEPPER_UPDATE_PERIOD_MS    (5)   // For smooth stepper movement
#define FAN_CONTROL_LOGIC_PERIOD_MS     (100)

// ==============================================================================
// 3. Pin Mapping for HALs (STM32F401RC specific GPIO assignments)
//    These map the generic Port_x/Pin_x from HAL_USER files to MCAL.h types.
//    Ensure these pins are physically available and do not conflict.
// ==============================================================================

// Generic Port and Pin remapping for HAL compatibility (R5F11BBC -> STM32F401RC)
#define Port_0 port_a
#define Port_1 port_b
#define Port_2 port_c
#define Port_3 port_d
#define Port_4 port_e
#define Port_5 port_a  // Remap to available GPIOA for consistency, as GPIOH has limited pins
#define Port_7 port_b  // Remap to available GPIOB
#define Port_12 port_d // Remap to available GPIOD

#define Pin_0 pin_0
#define Pin_1 pin_1
#define Pin_2 pin_2
#define Pin_3 pin_3
#define Pin_4 pin_4
#define Pin_5 pin_5
#define Pin_6 pin_6
#define Pin_7 pin_7
#define Pin_8 pin_8
#define Pin_9 pin_9
#define Pin_10 pin_10
#define Pin_11 pin_11
#define Pin_12 pin_12
#define Pin_13 pin_13
#define Pin_14 pin_14
#define Pin_15 pin_15

// --- 3.1 Buzzer Configuration (HAL_BUZZER_USER.h) ---
#define BUZZ0_ID (0)
#define BUZZ1_ID (1)
#define BUZZ_NUM BUZZ1_ID // Use BUZZ1 as per HAL_BUZZER_USER.h

#define FAN_BUZZER0_PORT port_a
#define FAN_BUZZER0_PIN  pin_4
#define FAN_BUZZER1_PORT port_a // Using PA4 for Buzzer1 based on pin availability
#define FAN_BUZZER1_PIN  pin_4 // Re-using pin, as BUZZ_NUM ensures only one is active

// --- 3.2 IR Sensor Configuration (IR_user.h) ---
#define IR_Tx_PORT  port_a
#define IR_Tx_PIN   pin_5
#define IR_Rx_PORT  port_a
#define IR_Rx_PIN   pin_6

// --- 3.3 Push Button (PB) Configuration (HAL_PB_USER.h) ---
#define SW_ID       (0)
#define SW_ID_PORT  port_a
#define SW_ID_PIN   pin_7
#define SW_ID_edge  rising_edge // Assuming internal pull-up by MCAL_GPIO

// --- 3.4 7-Segment Display (SSD) Configuration (HAL_SSD_Config.h) ---
// Note: SSD_MAX (2) and SSD_FLASH_TIME (100) are already in HAL_SSD_Config.h
// Common Anode/Cathode settings are also in HAL_SSD_Config.h
// COM0_PORT (Port_1->port_b), COM0_PIN (Pin_2->pin_2)
// COM1_PORT (Port_1->port_b), COM1_PIN (Pin_3->pin_3)
// A_PORT (Port_2->port_c), A_PIN (Pin_0->pin_0)
// B_PORT (Port_2->port_c), B_PIN (Pin_3->pin_3)
// C_PORT (Port_0->port_a), C_PIN (Pin_0->pin_0)
// D_PORT (Port_12->port_d), D_PIN (Pin_0->pin_0)
// E_PORT (Port_0->port_a), E_PIN (Pin_1->pin_1)
// F_PORT (Port_2->port_c), F_PIN (Pin_2->pin_2)
// G_PORT (Port_2->port_c), G_PIN (Pin_1->pin_1)
// All these mappings are handled by the Port_x/Pin_x definitions above.

// --- 3.5 Keypad Configuration (keypad_config.h) ---
// KEYPAD_COL_MAX_NO (2), KEYPAD_ROW_MAX_NO (4) are in keypad_config.h
// Map keypad pins
#define KEYPAD_COL0_PORT    port_d
#define KEYPAD_COL0_PIN     pin_0
#define KEYPAD_COL1_PORT    port_d
#define KEYPAD_COL1_PIN     pin_1

#define KEYPAD_ROW0_PORT    port_d
#define KEYPAD_ROW0_PIN     pin_2
#define KEYPAD_ROW1_PORT    port_d
#define KEYPAD_ROW1_PIN     pin_3
#define KEYPAD_ROW2_PORT    port_d
#define KEYPAD_ROW2_PIN     pin_4
#define KEYPAD_ROW3_PORT    port_d
#define KEYPAD_ROW3_PIN     pin_5

// --- 3.6 NTC Thermistor Configuration (ntc_config.h) ---
// NTC_MAX_NO (1) from ntc_config.h
#define FAN_NTC_ADC_CHANNEL        adc_channel_1 // Use PA1 for ADC input
#define FAN_NTC_ID                 (0)           // ID for the single NTC sensor
#define NTC_NOMINAL_RESISTANCE     (10000.0F)    // Ohms, from datasheet of NTC
#define NTC_BETA_COEFFICIENT       (3950.0F)     // Beta value, from datasheet
#define NTC_SERIES_RESISTANCE      (10000.0F)    // Ohms, value of series resistor

// --- 3.7 Stepper Motor Configuration (Stepper_motor_user.h) ---
// STEPPER_MOTOR_MAX (1) and MAX_NUMBER_OF_TERMINALS (4) from Stepper_motor_user.h
// Map stepper motor pins
#define FAN_STEPPER_COIL_A1_PORT    port_e
#define FAN_STEPPER_COIL_A1_PIN     pin_0
#define FAN_STEPPER_COIL_A2_PORT    port_e
#define FAN_STEPPER_COIL_A2_PIN     pin_1
#define FAN_STEPPER_COIL_B1_PORT    port_e
#define FAN_STEPPER_COIL_B1_PIN     pin_2
#define FAN_STEPPER_COIL_B2_PORT    port_e
#define FAN_STEPPER_COIL_B2_PIN     pin_3

// --- 3.8 Touch Pad Configuration (Touch_Pad_user.h) ---
// MAX_touchs (4) from Touch_Pad_user.h
// Map touch pad pins
#define POWER_TOUCH_PORT            port_a
#define POWER_TOUCH_PIN             pin_8
#define NORMAL_TOUCH_PORT           port_a
#define NORMAL_TOUCH_PIN            pin_9
#define COLD_TOUCH_PORT             port_a
#define COLD_TOUCH_PIN              pin_10
#define ICE_TOUCH_PORT              port_a
#define ICE_TOUCH_PIN               pin_11

// ==============================================================================
// 4. Fan Application Logic Configuration
// ==============================================================================
#define FAN_TEMP_THRESHOLD_HIGH     (30.0F) // Celsius
#define FAN_TEMP_THRESHOLD_MEDIUM   (25.0F) // Celsius
#define FAN_TEMP_THRESHOLD_COLD     (20.0F) // Celsius

#define FAN_SPEED_LOW_PERCENT       (20)
#define FAN_SPEED_MEDIUM_PERCENT    (50)
#define FAN_SPEED_HIGH_PERCENT      (80)
#define FAN_SPEED_ICE_PERCENT       (100) // Max speed for "ice" mode

// Stepper motor steps per control logic cycle (tune for desired speed/responsiveness)
// These are relative steps that the stepper motor should try to maintain per update cycle
#define FAN_STEPS_LOW               (1)
#define FAN_STEPS_MEDIUM            (3)
#define FAN_STEPS_HIGH              (5)
#define FAN_STEPS_ICE               (7)

// Optional: Debug UART channel
#define UART_DEBUG_CHANNEL          uart_channel_2 // Example: USART2

#endif // FAN_USER_H