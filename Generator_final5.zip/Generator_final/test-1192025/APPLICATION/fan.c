#include "fan.h"
#include <stdio.h> // For snprintf, if needed for debug/display

// ==============================================================================
// INTERNAL ADAPTATIONS FOR HALs
// The provided HALs use custom GPIO types and headers. These are remapped here.
// ==============================================================================

// Remap HAL GPIO types to MCAL types
#define gpio_port_t t_port
#define gpio_pin_t t_pin
#define pin_level_t tbyte
#define LOW 0
#define HIGH 1

// MCAL GPIO functions used by HALs need adaptations for 'normal_usage' parameter
// The original HALs might also include other GPIO.h from different MCUs, remapping to MCAL.h
#define MCAL_R5F11BBC_GPIO_H
#define MCAL_General_Config_H
#define GPIO_H

// --- HAL_BUZZER specific adaptations ---
// MCAL_BUZZER_OUTPUT.h is missing, implementing its functions via MCAL GPIO.
#ifndef MCAL_BUZZER_OUTPUT_H
#define MCAL_BUZZER_OUTPUT_H

/**
 * @brief Initializes the buzzer output pin.
 * @param buzzer_id The ID of the buzzer (e.g., BUZZ0, BUZZ1 from fan_user.h).
 */
void BUZZER_OUTPUT_Init(tbyte buzzer_id)
{
    WDT_Reset();
    if (buzzer_id == BUZZ0_ID)
    {
        GPIO_Output_Init(FAN_BUZZER0_PORT, FAN_BUZZER0_PIN, 0);
    }
    else if (buzzer_id == BUZZ1_ID)
    {
        GPIO_Output_Init(FAN_BUZZER1_PORT, FAN_BUZZER1_PIN, 0);
    }
}

/**
 * @brief Enables the buzzer (sets pin high).
 * @param buzzer_id The ID of the buzzer.
 */
void BUZZER_OUTPUT_Enable(tbyte buzzer_id)
{
    WDT_Reset();
    if (buzzer_id == BUZZ0_ID)
    {
        GPIO_Value_Set(FAN_BUZZER0_PORT, FAN_BUZZER0_PIN, 1);
    }
    else if (buzzer_id == BUZZ1_ID)
    {
        GPIO_Value_Set(FAN_BUZZER1_PORT, FAN_BUZZER1_PIN, 1);
    }
}

/**
 * @brief Disables the buzzer (sets pin low).
 * @param buzzer_id The ID of the buzzer.
 */
void BUZZER_OUTPUT_Disable(tbyte buzzer_id)
{
    WDT_Reset();
    if (buzzer_id == BUZZ0_ID)
    {
        GPIO_Value_Set(FAN_BUZZER0_PORT, FAN_BUZZER0_PIN, 0);
    }
    else if (buzzer_id == BUZZ1_ID)
    {
        GPIO_Value_Set(FAN_BUZZER1_PORT, FAN_BUZZER1_PIN, 0);
    }
}
#endif // MCAL_BUZZER_OUTPUT_H

// Placeholder for `normal_usage` parameter removal from HAL GPIO calls
#undef GPIO_Output_Init
#define GPIO_Output_Init(port, pin, value, ...) GPIO_Output_Init(port, pin, value)
#undef GPIO_Input_Init
#define GPIO_Input_Init(port, pin, ...) GPIO_Input_Init(port, pin)

// Keypad HAL uses GPIO_Pin_Output_Init and GPIO_Set_Pin_Value etc.
// Remap these to MCAL API.
#undef GPIO_Pin_Output_Init
#define GPIO_Pin_Output_Init(port, pin) GPIO_Output_Init(port, pin, 0)
#undef GPIO_Set_Pin_Value
#define GPIO_Set_Pin_Value(port, pin, value) GPIO_Value_Set(port, pin, value)
#undef GPIO_Pin_Input_Init
#define GPIO_Pin_Input_Init(port, pin) GPIO_Input_Init(port, pin)
#undef GPIO_Get_Pin_Value
#define GPIO_Get_Pin_Value(port, pin) GPIO_Value_Get(port, pin)

// NTC HAL uses ADC_Get() and select_mode
#undef ADC_Get
#define ADC_Get() ADC_Get_POLLING(FAN_NTC_ADC_CHANNEL) // Assume a single NTC
#undef select_mode
#define select_mode adc_mode_single_conversion

// Stepper Motor HAL
#undef Stepper_motor_user_H // Prevents double definition issues
#undef Stepper_motor_H      // Prevents double definition issues

// No specific DAC or I2S usage for fan control, skipping their HALs if they were provided.
// IR, Keypad, TouchPad, PB HALs are used directly, with GPIO type remapping.

// ==============================================================================
// STATIC VARIABLES AND FORWARD DECLARATIONS
// ==============================================================================

static Fan_State_t s_fan_state = FAN_STATE_OFF;
static float s_current_temperature = 0.0f;
static tbyte s_fan_speed_percent = 0; // 0-100% for display

// Stepper Motor structure for initialization
static STEPPER_MOTOR_TERMINALS_t fan_stepper_motor =
{
    .MOTOR_COIL_PORT = {FAN_STEPPER_COIL_A1_PORT, FAN_STEPPER_COIL_A2_PORT, FAN_STEPPER_COIL_B1_PORT, FAN_STEPPER_COIL_B2_PORT},
    .MOTOR_COIL_PIN  = {FAN_STEPPER_COIL_A1_PIN,  FAN_STEPPER_COIL_A2_PIN,  FAN_STEPPER_COIL_B1_PIN,  FAN_STEPPER_COIL_B2_PIN},
    .STATE           = { .DIRECTION = RIGHT_DIRECTION, .NUM_STEPS = 0, .Actual_steps = 0 }
};

// NTC sensor structure
static ntc_t fan_ntc_sensor =
{
    .adc_channel        = FAN_NTC_ADC_CHANNEL,
    .id                 = FAN_NTC_ID,
    .nominal_resistance = NTC_NOMINAL_RESISTANCE,
    .beta               = NTC_BETA_COEFFICIENT,
    .series_resistance  = NTC_SERIES_RESISTANCE,
    .ref_volt           = NTC_REF_VOLTAGE // From ntc_config.h
};

// Keypad configuration for initialization
static keypad_t fan_keypad_config =
{
    .col_port_arr = {KEYPAD_COL0_PORT, KEYPAD_COL1_PORT},
    .row_port_arr = {KEYPAD_ROW0_PORT, KEYPAD_ROW1_PORT, KEYPAD_ROW2_PORT, KEYPAD_ROW3_PORT},
    .col_pin_arr  = {KEYPAD_COL0_PIN,  KEYPAD_COL1_PIN},
    .row_pin_arr  = {KEYPAD_ROW0_PIN,  KEYPAD_ROW1_PIN,  KEYPAD_ROW2_PIN,  KEYPAD_ROW3_PIN}
};

// --- Scheduler Callback ---
static void (*s_scheduler_tick_callback)(void) = NULL;

// ==============================================================================
// SCHEDULER TIMER INTEGRATION (using MCAL_TIMER TIM2)
// ==============================================================================

/**
 * @brief Initializes the Interval Timer for the scheduler using TIM2.
 * @param clock_source Placeholder (unused).
 * @param Tick_Time_ms The desired tick time in milliseconds.
 */
void Interval_Timer_Init(void* clock_source, t_Tick_Time Tick_Time_ms)
{
    (void)clock_source; // Suppress unused parameter warning
    TIMER_Init(TIMER_SCHEDULER_CHANNEL);
    TIMER_Set_Time_ms(TIMER_SCHEDULER_CHANNEL, Tick_Time_ms);
}

/**
 * @brief Sets the ISR callback for the Interval Timer.
 * @param callback Pointer to the function to be called by the timer ISR.
 */
void Interval_Timer_ISR_Callback(void (*callback)(void))
{
    s_scheduler_tick_callback = callback;
}

/**
 * @brief Enables the Interval Timer.
 */
void Interval_Timer_Enable(void)
{
    TIMER_Enable(TIMER_SCHEDULER_CHANNEL);
    // Also need to enable TIM2 interrupt in NVIC. (Not part of MCAL API)
    // __NVIC_EnableIRQ(TIM2_IRQn); // Example CMSIS call
}

/**
 * @brief TIM2 Interrupt Service Routine.
 *        This function clears the interrupt flag and calls the scheduler's tick function.
 */
void TIM2_IRQHandler(void)
{
    if (P_TIM2->SR & (1UL << 0)) // Check UIF flag (Update Interrupt Flag)
    {
        P_TIM2->SR &= ~(1UL << 0); // Clear UIF flag
        if (s_scheduler_tick_callback != NULL)
        {
            s_scheduler_tick_callback();
        }
    }
}

// ==============================================================================
// APPLICATION TASKS
// ==============================================================================

/**
 * @brief Task to update NTC temperature reading.
 */
void Fan_NTC_Update_Task(void)
{
    ntc_update();
    ntc_get_temperature_celsius(FAN_NTC_ID, &s_current_temperature);
}

/**
 * @brief Task to update SSD display with fan speed.
 */
void Fan_SSD_Update_Task(void)
{
    tbyte tens = s_fan_speed_percent / 10;
    tbyte ones = s_fan_speed_percent % 10;
    SSD_2Digits_Set(tens, ones);
    SSD_Update();
}

/**
 * @brief Task to update push button states.
 */
void Fan_PB_Update_Task(void)
{
    PB_Update();
}

/**
 * @brief Task to update touch pad states.
 */
void Fan_Touch_Pad_Update_Task(void)
{
    TOUCH_PAD_update();
}

/**
 * @brief Task to update keypad states.
 */
void Fan_Keypad_Update_Task(void)
{
    keypad_update();
}

/**
 * @brief Task to update buzzer state.
 */
void Fan_Buzzer_Update_Task(void)
{
    Buzzer_Update();
}

/**
 * @brief Task to update stepper motor.
 */
void Fan_Stepper_Motor_Update_Task(void)
{
    STEPPER_MOTOR_update();
}

/**
 * @brief Main fan control logic task.
 *        Reads inputs and updates fan state and outputs.
 */
void Fan_Control_Logic_Task(void)
{
    // Handle Touch Pad inputs
    if (TOUCH_PAD_get_state(POWER_TOUCH) == TOUCH_PRESSED)
    {
        Buzzer_Init(BUZZ1_ID); // Ensure buzzer is initialized before setting tone
        if (s_fan_state == FAN_STATE_OFF)
        {
            s_fan_state = FAN_STATE_LOW;
            Buze_Tone_Set(buz);
        }
        else
        {
            s_fan_state = FAN_STATE_OFF;
            Buze_Tone_Set(mute);
        }
    }

    if (s_fan_state != FAN_STATE_OFF)
    {
        // Adjust fan speed based on temperature thresholds
        if (s_current_temperature > FAN_TEMP_THRESHOLD_HIGH)
        {
            s_fan_state = FAN_STATE_HIGH;
            Buze_Tone_Set(alarm); // Optional: alarm on high temp
        }
        else if (s_current_temperature > FAN_TEMP_THRESHOLD_MEDIUM)
        {
            s_fan_state = FAN_STATE_MEDIUM;
        }
        else if (s_current_temperature < FAN_TEMP_THRESHOLD_COLD)
        {
            s_fan_state = FAN_STATE_COLD;
        }
        else
        {
            s_fan_state = FAN_STATE_LOW;
        }
    }

    // Map fan state to actual fan speed percentage and motor steps
    switch (s_fan_state)
    {
        case FAN_STATE_OFF:
            s_fan_speed_percent = 0;
            STEPPER_MOTOR_set(RIGHT_DIRECTION, 0); // Stop motor (0 steps)
            break;
        case FAN_STATE_LOW:
            s_fan_speed_percent = FAN_SPEED_LOW_PERCENT;
            STEPPER_MOTOR_set(RIGHT_DIRECTION, FAN_STEPS_LOW);
            break;
        case FAN_STATE_MEDIUM:
            s_fan_speed_percent = FAN_SPEED_MEDIUM_PERCENT;
            STEPPER_MOTOR_set(RIGHT_DIRECTION, FAN_STEPS_MEDIUM);
            break;
        case FAN_STATE_HIGH:
            s_fan_speed_percent = FAN_SPEED_HIGH_PERCENT;
            STEPPER_MOTOR_set(RIGHT_DIRECTION, FAN_STEPS_HIGH);
            break;
        case FAN_STATE_ICE:
            s_fan_speed_percent = FAN_SPEED_ICE_PERCENT;
            STEPPER_MOTOR_set(RIGHT_DIRECTION, FAN_STEPS_ICE);
            break;
        default:
            s_fan_speed_percent = 0;
            STEPPER_MOTOR_set(RIGHT_DIRECTION, 0);
            break;
    }

    // Handle other keypad/PB inputs for manual overrides or modes if implemented
    if (PB_Get(SW_ID) == 1)
    {
        // Example: Toggle fan state with button
        if (s_fan_state == FAN_STATE_LOW) s_fan_state = FAN_STATE_MEDIUM;
        else if (s_fan_state == FAN_STATE_MEDIUM) s_fan_state = FAN_STATE_HIGH;
        else if (s_fan_state == FAN_STATE_HIGH) s_fan_state = FAN_STATE_OFF;
        else s_fan_state = FAN_STATE_LOW;
        Buze_Tone_Set(buz);
    }

    // For debugging, print state (if a UART is configured)
    // char buffer[50];
    // snprintf(buffer, sizeof(buffer), "Temp: %.2fC, State: %d, Speed: %d%%\r\n", s_current_temperature, s_fan_state, s_fan_speed_percent);
    // UART_send_string(UART_DEBUG_CHANNEL, buffer);
}

// ==============================================================================
// APPLICATION ENTRY POINTS
// ==============================================================================

/**
 * @brief Initializes the fan application middleware.
 *        This includes MCU configuration, HALs, and the scheduler.
 */
void fan_init(void)
{
    // 1. Configure MCU (system voltage, WDT, etc.)
    MCU_Config_Init(sys_volt_3v);

    // 2. Initialize Scheduler
    tt_init(FAN_SCHEDULER_TICK_MS); // Initialize scheduler with defined tick time
    Interval_Timer_ISR_Callback(TT_ISR); // Set scheduler's ISR callback

    // 3. Initialize HAL components
    Buzzer_Init(BUZZ_NUM); // Use the BUZZ_NUM from HAL_BUZZER_USER.h
    IR_Init();
    PB_Init(SW_ID, SW_ID_PORT, SW_ID_PIN, SW_ID_edge);
    SSD_Init();
    keypad_init(&fan_keypad_config); // Pass the configured keypad struct
    ntc_init(&fan_ntc_sensor); // Initialize NTC
    STEPPER_MOTOR_Init(&fan_stepper_motor);
    TOUCH_PAD_Init();

    // 4. Add tasks to the scheduler
    tt_add_task(Fan_NTC_Update_Task, 0, FAN_NTC_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_SSD_Update_Task, 0, FAN_SSD_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_PB_Update_Task, 0, FAN_PB_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_Touch_Pad_Update_Task, 0, FAN_TOUCH_PAD_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_Keypad_Update_Task, 0, FAN_KEYPAD_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_Buzzer_Update_Task, 0, FAN_BUZZER_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_Stepper_Motor_Update_Task, 0, FAN_STEPPER_UPDATE_PERIOD_MS / FAN_SCHEDULER_TICK_MS);
    tt_add_task(Fan_Control_Logic_Task, 0, FAN_CONTROL_LOGIC_PERIOD_MS / FAN_SCHEDULER_TICK_MS);

    // 5. Enable global interrupts and start the scheduler
    Global_interrupt_Enable();
    tt_start(); // Start the scheduler (will enable its underlying timer)
}

/**
 * @brief The main loop for the fan application.
 *        This function should be called repeatedly in `main()`.
 */
void fan_main_loop(void)
{
    // The main loop does nothing but allow the scheduler to run tasks in the background.
    // tt_dispatch_task() is implicitly called by the timer ISR and the main loop is empty.
    // If tt_dispatch_task was blocking, it would be called here.
    // Since tt_scheduler.c's tt_dispatch_task also calls tt_sleep(), this loop is essentially:
    // while(1) { tt_sleep(); } // or nothing, relying on ISR to wake and process.
    // The provided tt_scheduler.c's tt_dispatch_task is meant to be called in main loop.
    tt_dispatch_task(); // Dispatch tasks when not in ISR
}
