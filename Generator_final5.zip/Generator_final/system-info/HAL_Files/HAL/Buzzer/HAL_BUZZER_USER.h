

#ifndef HAL_BIZZER_USER_H_
#define HAL_BIZZER_USER_H_
/*Choose Buzzer Number :
                        1-BUZZ0       
                        2-BUZZ1  

*/						 

#define  BUZZ_NUM       BUZZ1


#endif