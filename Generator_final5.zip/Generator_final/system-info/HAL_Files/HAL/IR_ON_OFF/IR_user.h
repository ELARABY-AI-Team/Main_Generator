/*
 * IR_user.h
 *
 *  Created on: Dec 18, 2023
 *      Author: AHENDA01
 */

#ifndef HAL_IR_IR_USER_H_
#define HAL_IR_IR_USER_H_

#define  IR_Tx_PORT         Port_3
#define  IR_Tx_PIN          Pin_1
#define  IR_Rx_PORT       	Port_1
#define  IR_Rx_PIN 		    Pin_1

#endif /* HAL_IR_IR_USER_H_ */
