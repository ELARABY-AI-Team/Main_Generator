/*
 * Touch_Pad_user.c
 *
 *  Created on: Dec 11, 2023
 *      Author: AHENDA01
 */
#include "Touch_Pad_user.h"

const touch_pad_config_t touch_config[] =
{
   //GPIOx, PIN_x
	{Port_1, Pin_2},
	{Port_1, Pin_3},
	{Port_1, Pin_5},
	{Port_1, Pin_6},
};
