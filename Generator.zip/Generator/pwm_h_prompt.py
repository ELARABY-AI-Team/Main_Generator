from datetime import datetime

def pwm_h_prompt(mcu_name):
    current_date = datetime.now().strftime("%Y-%m-%d")

    return f"""Generate a production-ready GPIO.h header file for the {mcu_name} microcontroller that strictly follows these requirements:

1. FILE STRUCTURE:
#ifndef {mcu_name}_PWM_H_
#define {mcu_name}_PWM_H_
#include "{mcu_name}_MAIN.h"
#include "{mcu_name}_GPIO.h"


/* ==================== PWM CHANNEL ENUM (DO NOT MODIFY) and donot write that inside the file please ==================== */
/*
 * - typedef enum t_pwm_channel:
 *   - Identify the total number of channels supported by Timer {timer} and please mention timer number as a comment
 *   - Use official datasheets or reference manuals of {mcu_name}
 *   - For each channel found for the {timer} (e.g., CH1, CH2, ...), generate enum entries
 *   - Each enum entry name must follow the naming conventions typically used for {mcu_name},
 *     and clearly indicate the timer and channel (e.g., TIMx_CHx or similar per MCU standard)
 *   - Each entry must include a single-line comment:
 *       - /* PDF Reference */ *if confirmed from official documentation*
 *       - /* Assumed – please verify */ *if inferred from context*
 *   - The enum must be named `t_pwm_channel` and follow production-grade C conventions.
 */


/* ==================== FUNCTION DECLARATIONS ==================== */
void PWM_Init(TRD_Channel_t TRD_Channel);
void PWM_Set_Freq(TRD_Channel_t TRD_Channel, tlong frequency, tbyte duty);
void PWM_Start(TRD_Channel_t TRD_Channel);
void PWM_Stop(TRD_Channel_t TRD_Channel);
void PWM_PowerOff(void);

#endif /* {mcu_name}_GPIO_H_ */

/* ==================== STRICT REQUIREMENTS ==================== */

1. CODING STANDARDS:
• Absolute compliance with AUTOSAR/MISRA-C guidelines
• No implementations - declarations only
• Use exact specified enum/function names
• All types (tbyte, tword) from {mcu_name}_MAIN.h
• No additional macros/typedefs
• No static functions
• Single-line comments only

2. OUTPUT:
• Fully compilable C header
• Production-grade quality
• No placeholders or TODOs
• Automotive/mission-critical safety level"""