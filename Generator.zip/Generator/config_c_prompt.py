import json

with open("mcu_config.json", "r") as f:
    config = json.load(f)

mcu_name = config.get("mcu_name", "UNKNOWN")


with open("app_settings.json", "r") as f:
    config = json.load(f)

voltage = config.get("voltage", "UNKNOWN")
clock_source = config.get("clock_source", "UNKNOWN")


config_c_prompt = f"""
Create a clean and production-ready `config.c` file for the **{mcu_name}** microcontroller.  
This file must implement the functions declared in `config.h`, using the macros and typedefs from `{mcu_name}_MAIN.h`.

---

### 🔗 File Linkage:

- Add `#include "{mcu_name}_config.h"` and `#include "{mcu_name}_MAIN.h"` at the top.
- Do not redefine macros like `SET_BIT`, `GPIO_SAFEGUARD_Init()`, or typedefs like `tword` — just use them as-is.

---

### 🔧 Required Function Implementations:

Implement the following functions exactly as described below.

#### `void mcu_config_Init(void)`
Call the functions in this strict sequence:
1. `safe_guards()` — must call `GPIO_SAFEGUARD_Init()` and `Registers_SAFEGUARD_Init()`
2. `LVR_init()` → initialize Low Voltage Reset (LVR) threshold for operation at {voltage}V
3. `LVR_Enable()` — enables the LVR
4. `WDT_INIT()` — sets up the Watchdog Timer with a timeout ≥ 8ms
5. `WDT_Enable()` — enables the WDT
6. `CLC_Init()` → configure clock source using `{clock_source}`

Also implement:  
#### `void WDI_Reset(void)` — to refresh the watchdog timer

---

### 🔒 Function Visibility Rules:

- Mark these **static**:  
  `safe_guards()`, `LVR_init()`, `LVR_Enable()`, `WDT_INIT()`

- These **must NOT be static**:  
  `WDT_Enable()`, `CLC_Init()`

---

### ⚠️ Safety and Quality Guidelines:

- Return `0` for success, `<0` for failure.
- Add timeout logic when polling hardware or clock flags.
- Avoid all magic numbers — use macros from `main.h` instead.
- Use short inline comments where meaningful (e.g., register logic).

---

### 📘 Comment Style:

- Add concise function headers.
- No placeholders or redundant comments.
- Only comment important hardware logic or assumptions.
- If you assume any register or value, clearly write:  
  `"// Assumed — please change if needed"`

---

### 🔄 Output Requirements:

- Output must be a **complete, working C file**.
- The file should begin with the includes and then contain **only** function implementations.
- No pseudocode, no educational remarks, no filler content.
- Use only the exact function names and structure described above.

---

🚫 **DO NOT**:
- Explain what the code is doing.
- Describe the purpose of functions.
- Add summaries, introductions, or file headers.
- donot add any more functions from your mind.
- Output anything other than the **pure C code** for `config.c`.

✅ Output only the C code — start from includes and go straight into the function implementations.
"""

