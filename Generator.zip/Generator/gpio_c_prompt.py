from datetime import datetime

def gpio_c_prompt(mcu_name):
    current_date = datetime.now().strftime("%Y-%m-%d")

    return f"""Write a production-grade GPIO driver implementation file named `{mcu_name}_GPIO.c` that matches the `{mcu_name}_GPIO.h` header file exactly.

/**Includes ============================================================================*/
#include "{mcu_name}_GPIO.h"

===================== CORE RULES =====================
1. Use only the `tport` and `tpin` enums defined in `{mcu_name}_GPIO.h`.
2. Do not assume or create extra ports/pins.
3. Treat all port names case-insensitively always like that(port_A) (e.g., Port_A == port_A).
4. DO NOT use placeholder registers like Px, PMx, PUx, or POMx.
5. Instead, search for and use the **real hardware register names** for the {mcu_name} microcontroller family.
   - You MUST retrieve the correct GPIO register names (or use prior knowledge if known).
   - These include:
     • Output register
     • Input register
     • Direction/mode register
     • Pull-up/down configuration register
     • Output type register
6. Do not generate separate files or duplicate code per port.
7. All logic must reside in this single .c file.
8. Use exactly the same indentation, spacing, and brace style as this example:

void GPIO_Value_Set(tport port, tpin pin, tbyte value)

    WDT_Reset();
    switch(port)
    
        case port_A:
            if(value & (1 << pin)) SET_BIT(GPIOA->ODR, pin); else CLR_BIT(GPIOA->ODR, pin);
            break;
        case port_B:
            if(value & (1 << pin)) SET_BIT(GPIOB->ODR, pin); else CLR_BIT(GPIOB->ODR, pin);
            break;
        default:
            break;
    


9. Use provided macros: SET_BIT, CLR_BIT, TOG_BIT, GET_BIT.
10. Use `value & (1 << pin)` to determine logic level.
11. Each function must begin with `WDT_Reset();`
12. Use `switch(port)` for all port-based logic and always include a `default:` case.
13. Do not add any helper functions, global variables, or comments beyond what’s requested.
14. Match the function signatures and types exactly as declared in the header.
15. All port names in switch(port) must follow this format exactly: `port_A`, `port_B`, etc.

===================== GETTER RULE =====================
16. In every function that returns a value (like GPIO_Value_Get and GPIO_Direction_get):
    - Create a local variable (e.g., `ret_val`)
    - Assign the result to that variable inside the switch(port)
    - At the end of the function, return that variable using `return ret_val;`
    - NEVER return directly inside the switch-case.

===================== IMPLEMENT THESE FUNCTIONS =====================

1. void GPIO_Value_Set(tport port, tpin pin, tbyte value);
   - Call WDT_Reset();
   - Use switch(port):
     - For each case: if(value & (1 << pin)) → SET_BIT(Px, pin); else → CLR_BIT(Px, pin);
     - Use actual enum names from tport (e.g., port_A, port_B, ...)

2. tbyte GPIO_Value_Get(tport port, tpin pin);
   - Call WDT_Reset();
   - Generate a variable inside the function and return it at the end.
   - Use switch(port): assign ret_val = GET_BIT(Px, pin);

3. void GPIO_Value_Tog(tport port, tpin pin);
   - Call WDT_Reset();
   - Use switch(port): TOG_BIT(Px, pin);

4. t_direction GPIO_Direction_get(tport port, tpin pin);
   - Call WDT_Reset();
   - Generate a variable inside the function and return it at the end.
   - Use switch(port): assign ret_val = GET_BIT(PMx, pin);

5. void GPIO_Output_Init(tport port, tpin pin, tbyte value, t_usage usage, t_output_conn conn);
   - Call WDT_Reset();
   - Use `(do method)  while(GPIO_Direction_get(...) != output);`
   - In switch(port):
     - CLR_BIT(PUx, pin); // Disable pull-up
     - Set initial value: (value & (1 << pin)) ? SET_BIT(Px, pin) : CLR_BIT(Px, pin);
     - If usage == communication_usage → SET_BIT(POMx, pin); else → CLR_BIT(POMx, pin);
     - CLR_BIT(PMx, pin); // Set as output

6. void GPIO_Input_Init(tport port, tpin pin, t_usage usage, t_pull pull);
   - Call WDT_Reset();
   - Use `(do method)  while(GPIO_Direction_get(...) != input);`
   - In switch(port):
     - SET_BIT(PUx, pin); // Enable pull-up
     - If usage == communication_usage → SET_BIT(POMx, pin); else → CLR_BIT(POMx, pin);
     - SET_BIT(PMx, pin); // Set as input

===================== DO NOT =====================
• Do not assume additional pins or ports not listed in the header
• Do not write code for Port_0, Port_1, etc. — only use the actual tport values from the header
• Do not include any macros, typedefs, or helpers
• Do not generate comments or content outside the 6 functions above
• Do not use lowercase/uppercase variants separately — unify as defined in the header

===================== RESULT FORMAT =====================
• A single compilable C file named {mcu_name}_GPIO.c
• Contains ONLY the implementations of the 6 functions
• Fully aligned with the enums and types declared in {mcu_name}_GPIO.h
• Production-ready, clean, and strictly compliant with embedded C practices
"""








