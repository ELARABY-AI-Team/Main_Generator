# prompt2.py

import json

with open("mcu_config.json", "r") as f:
    config = json.load(f)

mcu_name = config.get("mcu_name", "UNKNOWN")

gpio_c_prompt = f"""Write a generic MCAL GPIO driver implementation file named `{mcu_name}_GPIO.c` that follows this exact structure and logic:

/**Includes ============================================================================*/
#include "{mcu_name}_GPIO.h"

/**Static Variables ====================================================================*/

/**Functions ===========================================================================*/

/* Implement the following functions using MCAL style, macros, and MCU logic awareness: */

1. void GPIO_Value_Set(tport port, tpin pin, tbyte value);
   - Call WDT_Reset();
   - switch(port) for each port (e.g., Port_0, Port_1, ...)
   - For each case:
     - If (value & (1 << pin)) use SET_BIT(Px, pin);
     - Else use CLR_BIT(Px, pin);
   - Do not assume 1 = HIGH; use value & (1 << pin)
*/

/*
2. tbyte GPIO_Value_Get(tport port, tpin pin);
   - Call WDT_Reset();
   - Return GET_BIT(Px, pin) per port
*/

/*
3. void GPIO_Value_Tog(tport port, tpin pin);
   - Call WDT_Reset();
   - Toggle with TOG_BIT(Px, pin)
*/

/*
4. t_direction GPIO_Direction_get(tport port, tpin pin);
   - Call WDT_Reset();
   - Return GET_BIT(PMx, pin) for each port
*/

/*
5. void GPIO_Output_Init(tport port, tpin pin, tbyte value, t_usage usage, t_output_conn conn);
   - Use (do method) while(GPIO_Direction_get(...) != output);
   - Inside switch(port):
     - CLR_BIT(PUx, pin); // Disable pull-up
     - if(value & (1 << pin)) → SET_BIT(Px, pin); else → CLR_BIT(Px, pin);
     - if usage == communication_usage → SET_BIT(POMx, pin); else → CLR_BIT(POMx, pin);
     - CLR_BIT(PMx, pin); // Set as output
*/

/*
6. void GPIO_Input_Init(tport port, tpin pin, t_usage usage);
   - Use (do method) while(GPIO_Direction_get(...) != input);
   - Inside switch(port):
     - SET_BIT(PUx, pin); // Enable pull-up
     - if usage == communication_usage → SET_BIT(POMx, pin); else → CLR_BIT(POMx, pin);
     - SET_BIT(PMx, pin); // Set as input
*/

/* Additional Notes:
 - Always call WDT_Reset() at the beginning of each function
 - Use macros: SET_BIT, CLR_BIT, TOG_BIT, GET_BIT
 - Do not assume logic high is always value == 1 it is depending on the pdf
 - Use value & (1 << pin) to determine logic level
 - Add default: in every switch for safety
*/
"""
