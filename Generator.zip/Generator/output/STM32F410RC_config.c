/***********************************************************************************************************************
* File Name      : config.c
* Description    : let user decide
* Author         : Technology Inovation Software Team
* Tester         : 
* Device(s)      : STM32F410RC
* Creation Date  : 2025-07-02
* Testing Date   : 
* @COPYRIGHT : ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP.
***********************************************************************************************************************/

#include "STM32F410RC_config.h"
#include "STM32F410RC_MAIN.h"

/**
 * @brief Initialize hardware safeguards.
 * This includes GPIO and Register safeguards.
 */
static void safe_guards(void)
{
    GPIO_SAFEGUARD_Init();       // Initialize GPIO safeguard
    Registers_SAFEGUARD_Init();  // Initialize Register safeguard
}

/**
 * @brief Initialize Low Voltage Reset (LVR) threshold.
 * Configures the PVD (Power Voltage Detector) to monitor the 3.3V level.
 */
static void LVR_init(void)
{
    // Ensure Power interface clock is enabled if needed for PWR register access
    // Assumed PWR clock is enabled elsewhere or is default ON.
    // If not, add RCC_APB1ENR_PWREN bit setting here.

    // Disable PVD before configuration
    // CLEAR_BIT(PWR->CR, PWR_CR_PVDE); // Assumed macro exists

    // Configure PVD level for 3.3V operation
    // CLEAR_BIT(PWR->CR, PWR_CR_PLS_Msk); // Assumed macros exist for PWR_CR and PLS field
    // SET_BIT(PWR->CR, BOR_VOLTAGE_3_3V); // Assumed BOR_VOLTAGE_3_3V maps to correct PLS setting
}

/**
 * @brief Enable the Low Voltage Reset (LVR).
 * Enables the configured PVD/BOR.
 */
static void LVR_Enable(void)
{
    // Enable PVD
    // SET_BIT(PWR->CR, PWR_CR_PVDE); // Assumed macro exists
}

/**
 * @brief Initialize the Watchdog Timer (IWDG).
 * Configures the IWDG prescaler and reload value for a timeout >= 8ms.
 * Assumes LSI is running (typ 32kHz).
 * Timeout = (RLR + 1) / (LSI / PR)
 * With PR=4, RLR=63, Timeout = (63 + 1) / (32000 / 4) = 64 / 8000 = 0.008s = 8ms.
 */
static void WDT_INIT(void)
{
    // Unlock IWDG registers
    IWDG->KR = IWDG_KR_UNLOCK; // Assumed macros exist for IWDG registers and keys

    // Set prescaler to 4
    IWDG->PR = IWDG_PR_DIV4; // Assumed IWDG_PR_DIV4 macro exists

    // Set reload value to 63 for 8ms timeout
    IWDG->RLR = IWDG_RLR_VALUE_63; // Assumed IWDG_RLR_VALUE_63 macro exists

    // Write reload value (to load PR and RLR into counter)
    IWDG->KR = IWDG_KR_RELOAD; // Assumed IWDG_KR_RELOAD macro exists

    // Registers are locked again automatically after PR/RLR write
}

/**
 * @brief Enable the Watchdog Timer (IWDG).
 * Starts the IWDG counter.
 */
void WDT_Enable(void)
{
    // Start IWDG (write 0xCCCC)
    IWDG->KR = IWDG_KR_START; // Assumed IWDG_KR_START macro exists
}

/**
 * @brief Configure the system clock source to Internal (HSI).
 * Sets HSI as the system clock and waits for it to stabilize.
 */
void CLC_Init(void)
{
    volatile uint32_t timeout_counter = TIMEOUT_VALUE; // Assumed TIMEOUT_VALUE macro exists

    // Enable HSI oscillator
    SET_BIT(RCC->CR, RCC_CR_HSION); // Assumed macros exist for RCC registers and bits

    // Wait for HSI to be ready
    while (!(READ_BIT(RCC->CR, RCC_CR_HSIRDY)) && (timeout_counter > 0)) // Assumed macros exist
    {
        timeout_counter--;
    }

    // Check if HSI is ready
    if (timeout_counter == 0)
    {
        // HSI did not become ready within timeout.
        // Add error handling or indicate failure if needed.
        // For this implementation, we proceed but clock might be unstable or not HSI.
    }

    // Select HSI as system clock source
    MODIFY_REG(RCC->CFGR, RCC_CFGR_SW_Msk, RCC_CFGR_SW_HSI); // Assumed macros exist for RCC_CFGR and SW field/value

    // Wait till HSI is used as system clock source
    timeout_counter = TIMEOUT_VALUE; // Reset timeout counter
    while (((READ_BIT(RCC->CFGR, RCC_CFGR_SW_Msk)) != RCC_CFGR_SW_HSI) && (timeout_counter > 0)) // Assumed macros exist
    {
         timeout_counter--;
    }

    // Check if system clock switched to HSI
    if (timeout_counter == 0)
    {
        // System clock did not switch to HSI within timeout.
        // Add error handling or indicate failure if needed.
    }
}

/**
 * @brief Refresh the Watchdog Timer (IWDG).
 * Prevents the watchdog reset by reloading the counter.
 */
void WDI_Reset(void)
{
    // Reload IWDG counter (write 0xAAAA)
    IWDG->KR = IWDG_KR_RELOAD; // Assumed IWDG_KR_RELOAD macro exists
}

/**
 * @brief Initialize the microcontroller configuration.
 * Sets up safeguards, LVR, WDT, and the clock source.
 */
void mcu_config_Init(void)
{
    safe_guards();    // 1. Initialize safeguards
    LVR_init();       // 2. Initialize LVR threshold (Assumed PVD/BOR)
    LVR_Enable();     // 3. Enable LVR (Assumed PVD/BOR)
    WDT_INIT();       // 4. Initialize WDT settings
    WDT_Enable();     // 5. Enable WDT
    CLC_Init();       // 6. Configure clock source to HSI
}