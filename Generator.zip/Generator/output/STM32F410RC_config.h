/***********************************************************************************************************************
* File Name      : config.h
* Description    : Configuration header for STM32F410RC, declaring functions and definitions used by config.c
* Author         : Technology Inovation Software Team
* Tester         :
* Device(s)      : STM32F410RC
* Creation Date  : 2025-07-02
* Testing Date   :
* @COPYRIGHT : ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP.
***********************************************************************************************************************/

#ifndef CONFIG_H_
#define CONFIG_H_

/*
 * Linking to main.h for fundamental types (tbyte, tword, tlong)
 * and common macros (SET_BIT, CLR_BIT, etc.)
 * These will NOT be redefined in this header.
 */
#include "STM32F410RC_MAIN.h"

/*
 * Use extern "C" to ensure C-style linkage for functions and variables
 * when compiled with a C++ compiler.
 */
#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************************************************************
 *  DEFINITIONS
 ***********************************************************************************************************************/

/**
 * @brief Symbolic return/error codes for configuration functions.
 */
#define CONFIG_OK   ((tbyte)0)  /**< Configuration successful */
#define CONFIG_FAIL ((tbyte)1)  /**< Configuration failed */

/**
 * @brief Optional feature enable/disable flags.
 * Define these to enable or disable specific features during configuration.
 */
#define ENABLE_WATCHDOG   1     /**< Define to 1 to enable Watchdog timer (IWDG or WWDG). Assume IWDG for now. */
#define ENABLE_DEBUG_UART 0     /**< Define to 1 to enable a Debug UART peripheral. Assume USART2 TX/RX. */
// Add other optional feature defines as needed by config.c
// Example: #define ENABLE_ADC_CALIBRATION 1

/***********************************************************************************************************************
 *  GLOBAL FUNCTION DECLARATIONS
 ***********************************************************************************************************************/

/**
 * @brief Initializes the microcontroller peripherals and clocks according to application needs.
 * This function is responsible for setting up system clocks, GPIOs, and other essential peripherals.
 * Safeguards (like GPIO_SAFEGUARD_Init) are expected to be called within config.c or main.c before or during this function.
 */
void mcu_config_Init(void);

/**
 * @brief Resets the Watchdog Timer (WDI - Watchdog Independent/Window).
 * This function should be called periodically to prevent a system reset.
 * Its implementation will depend on whether IWDG or WWDG is enabled (based on ENABLE_WATCHDOG).
 */
void WDI_Reset(void);

/***********************************************************************************************************************
 *  GLOBAL VARIABLES (Declare extern if needed by config.c, otherwise keep empty)
 ***********************************************************************************************************************/

// Example: extern tbyte config_status; // Uncomment and define if config.c needs a globally accessible status variable.

#ifdef __cplusplus
}
#endif

#endif /* CONFIG_H_ */