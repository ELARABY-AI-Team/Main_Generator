/***********************************************************************************************************************
* File Name      : let user decide
* Description    : let user decide
* Author         : Technology Inovation Software Team
* Tester         :
* Device(s)      : STM32F410RC
* Creation Date  : 2025-07-02
* Testing Date   :
* @COPYRIGHT : ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP.
***********************************************************************************************************************/

#ifndef STM32F410RC_GPIO_H_
#define STM32F410RC_GPIO_H_

/* Include required types from configuration file */
#include "STM32F410RC_Config.h"


/* ==================== REQUIRED ENUMS (DO NOT MODIFY) ==================== */

/**
 * @brief Defines the intended usage of the GPIO pin.
 */
typedef enum
{
    normal_usage = 0U,      /* Standard GPIO behavior */
    communication_usage     /* Used for specific communication interfaces (e.g., alternate function) */
} t_usage;

/**
 * @brief Defines the direction mode of the GPIO pin.
 */
typedef enum
{
    output = 0U,    /* Pin is configured as output */
    input,          /* Pin is configured as input */
    analog          /* Pin is configured in analog mode */
} t_direction;

/**
 * @brief Defines the pull resistor settings for input pins.
 */
typedef enum
{
    pull_up = 0U,   /* Internal pull-up resistor enabled */
    pull_down       /* Internal pull-down resistor enabled */
} t_pull;

/**
 * @brief Defines the output driving connection type.
 */
typedef enum
{
    push_pull = 0U, /* Output configured as push-pull */
    open_drain      /* Output configured as open-drain */
} t_output_conn;


/* ==================== HARDWARE DEFINITIONS ==================== */

/**
 * @brief Defines the available GPIO ports on the STM32F410RC.
 */
typedef enum
{
    port_A = 0U,    /* GPIO Port A */ /* PDF Reference */
    port_B,         /* GPIO Port B */ /* PDF Reference */
    port_C,         /* GPIO Port C */ /* PDF Reference */
    port_H          /* GPIO Port H */ /* PDF Reference */
} tport;

/**
 * @brief Defines the available pin numbers within a GPIO port.
 */
typedef enum
{
    pin_0 = 0U,     /* Pin 0 */ /* PDF Reference */
    pin_1,          /* Pin 1 */ /* PDF Reference */
    pin_2,          /* Pin 2 */ /* PDF Reference */
    pin_3,          /* Pin 3 */ /* PDF Reference */
    pin_4,          /* Pin 4 */ /* PDF Reference */
    pin_5,          /* Pin 5 */ /* PDF Reference */
    pin_6,          /* Pin 6 */ /* PDF Reference */
    pin_7,          /* Pin 7 */ /* PDF Reference */
    pin_8,          /* Pin 8 */ /* PDF Reference */
    pin_9,          /* Pin 9 */ /* PDF Reference */
    pin_10,         /* Pin 10 */ /* PDF Reference */
    pin_11,         /* Pin 11 */ /* PDF Reference */
    pin_12,         /* Pin 12 */ /* PDF Reference */
    pin_13,         /* Pin 13 */ /* PDF Reference */
    pin_14,         /* Pin 14 */ /* PDF Reference */
    pin_15          /* Pin 15 */ /* PDF Reference */
} tpin;


/* ==================== FUNCTION DECLARATIONS ==================== */

/**
 * @brief Initializes a GPIO pin for output mode.
 * @param port The GPIO port to initialize.
 * @param pin The pin number within the port.
 * @param value The initial output value (0 for low, 1 for high).
 * @param usage The intended usage of the pin (normal or communication).
 * @param conn The output connection type (push-pull or open-drain).
 */
void GPIO_Output_Init(tport port, tpin pin, tbyte value, t_usage usage, t_output_conn conn);

/**
 * @brief Initializes a GPIO pin for input mode.
 * @param port The GPIO port to initialize.
 * @param pin The pin number within the port.
 * @param usage The intended usage of the pin (normal or communication).
 * @param pull The pull resistor setting (pull-up or pull-down).
 */
void GPIO_Input_Init(tport port, tpin pin, t_usage usage, t_pull pull);

/**
 * @brief Gets the current direction mode of a GPIO pin.
 * @param port The GPIO port.
 * @param pin The pin number within the port.
 * @return The current direction mode (output, input, or analog).
 */
t_direction GPIO_Direction_get(tport port, tpin pin);

/**
 * @brief Sets the output value of a GPIO pin (must be configured as output).
 * @param port The GPIO port.
 * @param pin The pin number within the port.
 * @param value The desired output value (0 for low, 1 for high).
 */
void GPIO_Value_Set(tport port, tpin pin, tbyte value);

/**
 * @brief Gets the input value of a GPIO pin (must be configured as input).
 * @param port The GPIO port.
 * @param pin The pin number within the port.
 * @return The input value (0 for low, 1 for high).
 */
tbyte GPIO_Value_Get(tport port, tpin pin);

/**
 * @brief Toggles the output value of a GPIO pin (must be configured as output).
 * @param port The GPIO port.
 * @param pin The pin number within the port.
 */
void GPIO_Value_Tog(tport port, tpin pin);

#endif /* STM32F410RC_GPIO_H_ */