/***********************************************************************************************************************
* File Name      : STM32F410RC_GPIO.c
* Description    : Generic MCAL GPIO Driver implementation for STM32F410RC
* Author         : Technology Inovation Software Team (Based on user request)
* Tester         : 
* Device(s)      : STM32F410RC
* Creation Date  : 2025-07-02
* Testing Date   : 
* @COPYRIGHT : ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP.
***********************************************************************************************************************/

/**Includes ============================================================================*/
#include "STM32F410RC_GPIO.h"
#include "WDT.h" // Assuming WDT_Reset is declared here
#include "BIT_MACROS.h" // Assuming SET_BIT, CLR_BIT, TOG_BIT, GET_BIT are declared here

// Note: The following conceptual registers (Px, PMx, PUx, POMx) are used
// as required by the prompt's logic and macro usage.
// In a real STM32 MCAL, these macros (SET_BIT, etc.) would map the requested
// port/pin and conceptual register type (data, mode, pull-up, custom-usage)
// to the correct bit(s) in the actual STM32 GPIO registers (ODR/BSRR, IDR, MODER, PUPDR)
// considering the 2-bit configuration for MODER/PUPDR.
// This implementation assumes the BIT_MACROS.h file handles this internal mapping.
// Px: Conceptual Data Register (maps to BSRR for setting/clearing, IDR for getting)
// PMx: Conceptual Mode Register (maps to MODER lower bit - 0:Output, 1:Input as per prompt logic)
// PUx: Conceptual Pull-up Register (maps to PUPDR lower bit - 0:None, 1:Pull-up as per prompt logic)
// POMx: Conceptual Output Connection/Usage Register (custom, behavior undefined by standard STM32)

// Example conceptual mapping (assuming BIT_MACROS.h handles the details):
// #define Px(PORT_BASE)       ((volatile uint32_t*)(PORT_BASE)) // Placeholder
// #define PMx(PORT_BASE)      ((volatile uint32_t*)(PORT_BASE)) // Placeholder mapping to MODER
// #define PUx(PORT_BASE)      ((volatile uint32_t*)(PORT_BASE)) // Placeholder mapping to PUPDR
// #define POMx(PORT_BASE)     ((volatile uint32_t*)(PORT_BASE)) // Placeholder, custom register

/**Static Variables ====================================================================*/

/**Functions ===========================================================================*/

/**
 * @brief Sets the value of a specific GPIO pin.
 * @param port: The GPIO port (e.g., Port_A, Port_B).
 * @param pin: The pin number (0-15).
 * @param value: The value to set. Only the bit corresponding to the pin is relevant.
 *               If the bit (1 << pin) is set in 'value', the pin is set high.
 *               Otherwise, the pin is set low.
 */
void GPIO_Value_Set(tport port, tpin pin, tbyte value)
{
    WDT_Reset();

    // Assume Px macro or similar mechanism in BIT_MACROS.h
    // translates port enum to the correct GPIO peripheral base address.
    switch(port)
    {
        case Port_A:
            if (value & (1 << pin))
            {
                SET_BIT(GPIOA_BSRR, pin); // Assuming SET_BIT maps pin to BSRR_BSx
            }
            else
            {
                CLR_BIT(GPIOA_BSRR, pin + 16); // Assuming CLR_BIT maps pin to BSRR_BRx
            }
            break;
        case Port_B:
             if (value & (1 << pin))
            {
                SET_BIT(GPIOB_BSRR, pin);
            }
            else
            {
                CLR_BIT(GPIOB_BSRR, pin + 16);
            }
            break;
        case Port_C:
             if (value & (1 << pin))
            {
                SET_BIT(GPIOC_BSRR, pin);
            }
            else
            {
                CLR_BIT(GPIOC_BSRR, pin + 16);
            }
            break;
        // Add cases for other supported ports (e.g., Port_H for STM32F410RC)
        case Port_H: // Port H is available on STM32F410RC
             if (value & (1 << pin))
            {
                SET_BIT(GPIOH_BSRR, pin);
            }
            else
            {
                CLR_BIT(GPIOH_BSRR, pin + 16);
            }
            break;
        default:
            // Handle unknown port
            break;
    }
}

/**
 * @brief Gets the current value of a specific GPIO pin.
 * @param port: The GPIO port (e.g., Port_A, Port_B).
 * @param pin: The pin number (0-15).
 * @return tbyte: The value of the pin (0 or 1).
 */
tbyte GPIO_Value_Get(tport port, tpin pin)
{
    WDT_Reset();
    tbyte ret_val = 0; // Default return value

    // Assume Px macro or similar mechanism in BIT_MACROS.h
    // translates port enum to the correct GPIO peripheral base address.
    switch(port)
    {
        case Port_A:
            // Assuming GET_BIT reads from the Input Data Register (IDR)
            ret_val = (tbyte)GET_BIT(GPIOA_IDR, pin);
            break;
        case Port_B:
            ret_val = (tbyte)GET_BIT(GPIOB_IDR, pin);
            break;
        case Port_C:
            ret_val = (tbyte)GET_BIT(GPIOC_IDR, pin);
            break;
        // Add cases for other supported ports
        case Port_H:
            ret_val = (tbyte)GET_BIT(GPIOH_IDR, pin);
            break;
        default:
            // Handle unknown port
            break;
    }
    return ret_val;
}

/**
 * @brief Toggles the current value of a specific GPIO pin.
 * @param port: The GPIO port (e.g., Port_A, Port_B).
 * @param pin: The pin number (0-15).
 */
void GPIO_Value_Tog(tport port, tpin pin)
{
    WDT_Reset();

    // Assume Px macro or similar mechanism in BIT_MACROS.h
    // translates port enum to the correct GPIO peripheral base address.
    // Assuming TOG_BIT operates on the Output Data Register (ODR).
    switch(port)
    {
        case Port_A:
            TOG_BIT(GPIOA_ODR, pin);
            break;
        case Port_B:
            TOG_BIT(GPIOB_ODR, pin);
            break;
        case Port_C:
            TOG_BIT(GPIOC_ODR, pin);
            break;
        // Add cases for other supported ports
        case Port_H:
            TOG_BIT(GPIOH_ODR, pin);
            break;
        default:
            // Handle unknown port
            break;
    }
}

/**
 * @brief Gets the direction configuration of a specific GPIO pin.
 * @param port: The GPIO port (e.g., Port_A, Port_B).
 * @param pin: The pin number (0-15).
 * @return t_direction: The direction (input or output).
 *                     Returns 'input' if the conceptual PMx bit is 1, 'output' if 0.
 *                     This maps to STM32 MODER: Input (00) -> returns input (1), Output (01) -> returns output (0).
 */
t_direction GPIO_Direction_get(tport port, tpin pin)
{
    WDT_Reset();
    t_direction ret_dir = input; // Default return value

    // Assume PMx macro or similar mechanism in BIT_MACROS.h
    // translates port enum and pin to the correct bit(s) in the MODER register,
    // returning 1 if configured as input (MODER 00) and 0 if configured as output (MODER 01).
    switch(port)
    {
        case Port_A:
            ret_dir = (t_direction)GET_BIT(GPIOA_MODER_PMx, pin); // Assuming GET_BIT(MODER, pin) gets the conceptual PMx bit
            break;
        case Port_B:
            ret_dir = (t_direction)GET_BIT(GPIOB_MODER_PMx, pin);
            break;
        case Port_C:
            ret_dir = (t_direction)GET_BIT(GPIOC_MODER_PMx, pin);
            break;
        // Add cases for other supported ports
        case Port_H:
            ret_dir = (t_direction)GET_BIT(GPIOH_MODER_PMx, pin);
            break;
        default:
            // Handle unknown port
            break;
    }
    return ret_dir;
}


/**
 * @brief Initializes a specific GPIO pin as an output.
 * @param port: The GPIO port (e.g., Port_A, Port_B).
 * @param pin: The pin number (0-15).
 * @param value: The initial value to set for the output pin.
 * @param usage: The usage type (general_usage or communication_usage).
 * @param conn: The output connection type (parameter is present but not used in logic as per request).
 */
void GPIO_Output_Init(tport port, tpin pin, tbyte value, t_usage usage, t_output_conn conn)
{
    WDT_Reset();
    (void)conn; // Parameter not used as per logic steps in request

    // Assume PMx, PUx, POMx macros or similar mechanism in BIT_MACROS.h
    // translate port enum and pin to the correct bit(s) in the relevant registers.
    // Assume SET_BIT/CLR_BIT for PMx/PUx handle the 2-bit STM32 fields correctly
    // based on the requested logic (0=Output, 1=Input for PMx; 0=NoPull, 1=PullUp for PUx).
    switch(port)
    {
        case Port_A:
            // CLR_BIT(PUx, pin); // Disable pull-up: Maps to PUPDR 00 for the pin
            CLR_BIT(GPIOA_PUPDR_PUx, pin);

            // if(value & (1 << pin)) -> SET_BIT(Px, pin); else -> CLR_BIT(Px, pin);
            // Set initial value using BSRR
            if(value & (1 << pin))
            {
                SET_BIT(GPIOA_BSRR, pin);      // Set pin high
            }
            else
            {
                CLR_BIT(GPIOA_BSRR, pin + 16); // Set pin low
            }

            // if usage == communication_usage -> SET_BIT(POMx, pin); else -> CLR_BIT(POMx, pin);
            // Handle custom usage flag - POMx is conceptual
            if(usage == communication_usage)
            {
                SET_BIT(GPIOA_POMx, pin); // Assuming POMx exists conceptually
            }
            else
            {
                CLR_BIT(GPIOA_POMx, pin); // Assuming POMx exists conceptually
            }

            // CLR_BIT(PMx, pin); // Set as output: Maps to MODER 01 for the pin
            CLR_BIT(GPIOA_MODER_PMx, pin);
            break;

        case Port_B:
            CLR_BIT(GPIOB_PUPDR_PUx, pin);
            if(value & (1 << pin)) { SET_BIT(GPIOB_BSRR, pin); } else { CLR_BIT(GPIOB_BSRR, pin + 16); }
            if(usage == communication_usage) { SET_BIT(GPIOB_POMx, pin); } else { CLR_BIT(GPIOB_POMx, pin); }
            CLR_BIT(GPIOB_MODER_PMx, pin);
            break;

        case Port_C:
            CLR_BIT(GPIOC_PUPDR_PUx, pin);
            if(value & (1 << pin)) { SET_BIT(GPIOC_BSRR, pin); } else { CLR_BIT(GPIOC_BSRR, pin + 16); }
            if(usage == communication_usage) { SET_BIT(GPIOC_POMx, pin); } else { CLR_BIT(GPIOC_POMx, pin); }
            CLR_BIT(GPIOC_MODER_PMx, pin);
            break;

        // Add cases for other supported ports
        case Port_H:
            CLR_BIT(GPIOH_PUPDR_PUx, pin);
            if(value & (1 << pin)) { SET_BIT(GPIOH_BSRR, pin); } else { CLR_BIT(GPIOH_BSRR, pin + 16); }
            if(usage == communication_usage) { SET_BIT(GPIOH_POMx, pin); } else { CLR_BIT(GPIOH_POMx, pin); }
            CLR_BIT(GPIOH_MODER_PMx, pin);
            break;

        default:
            // Handle unknown port
            break;
    }

    // Use (do method) while(GPIO_Direction_get(...) != output);
    // Poll until the direction is confirmed as output
    do
    {
        WDT_Reset(); // Reset WDT inside the polling loop
    } while(GPIO_Direction_get(port, pin) != output);
}

/**
 * @brief Initializes a specific GPIO pin as an input.
 * @param port: The GPIO port (e.g., Port_A, Port_B).
 * @param pin: The pin number (0-15).
 * @param usage: The usage type (general_usage or communication_usage).
 */
void GPIO_Input_Init(tport port, tpin pin, t_usage usage)
{
    WDT_Reset();

    // Assume PMx, PUx, POMx macros or similar mechanism in BIT_MACROS.h
    // translate port enum and pin to the correct bit(s) in the relevant registers.
    // Assume SET_BIT/CLR_BIT for PMx/PUx handle the 2-bit STM32 fields correctly
    // based on the requested logic (0=Output, 1=Input for PMx; 0=NoPull, 1=PullUp for PUx).
    switch(port)
    {
        case Port_A:
            // SET_BIT(PUx, pin); // Enable pull-up: Maps to PUPDR 01 for the pin
            SET_BIT(GPIOA_PUPDR_PUx, pin);

            // if usage == communication_usage -> SET_BIT(POMx, pin); else -> CLR_BIT(POMx, pin);
            // Handle custom usage flag - POMx is conceptual
            if(usage == communication_usage)
            {
                SET_BIT(GPIOA_POMx, pin); // Assuming POMx exists conceptually
            }
            else
            {
                CLR_BIT(GPIOA_POMx, pin); // Assuming POMx exists conceptually
            }

            // SET_BIT(PMx, pin); // Set as input: Maps to MODER 00 for the pin
            SET_BIT(GPIOA_MODER_PMx, pin);
            break;

        case Port_B:
            SET_BIT(GPIOB_PUPDR_PUx, pin);
            if(usage == communication_usage) { SET_BIT(GPIOB_POMx, pin); } else { CLR_BIT(GPIOB_POMx, pin); }
            SET_BIT(GPIOB_MODER_PMx, pin);
            break;

        case Port_C:
            SET_BIT(GPIOC_PUPDR_PUx, pin);
            if(usage == communication_usage) { SET_BIT(GPIOC_POMx, pin); } else { CLR_BIT(GPIOC_POMx, pin); }
            SET_BIT(GPIOC_MODER_PMx, pin);
            break;

        // Add cases for other supported ports
        case Port_H:
            SET_BIT(GPIOH_PUPDR_PUx, pin);
            if(usage == communication_usage) { SET_BIT(GPIOH_POMx, pin); } else { CLR_BIT(GPIOH_POMx, pin); }
            SET_BIT(GPIOH_MODER_PMx, pin);
            break;

        default:
            // Handle unknown port
            break;
    }

    // Use (do method) while(GPIO_Direction_get(...) != input);
    // Poll until the direction is confirmed as input
    do
    {
        WDT_Reset(); // Reset WDT inside the polling loop
    } while(GPIO_Direction_get(port, pin) != input);
}

/***********************************************************************************************************************
* End of File
***********************************************************************************************************************/