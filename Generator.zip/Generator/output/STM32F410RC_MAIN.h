/**
 * @file main.h
 * @brief Main project header file containing common includes, typedefs,
 *        macros, and safeguard initialization functions for STM32F410RC.
 * @author Technology Inovation Software Team
 * @device STM32F410RC
 * @date 2025-07-02
 * @standard MISRA C
 * @copyright ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP
 */

#ifndef MAIN_H_
#define MAIN_H_

/*============================================================================*/
/* Includes                                                                   */
/*============================================================================*/

/* MCU-specific include */
#include "stm32f4xx.h"


/* Standard C headers - Included as specified */
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <inttypes.h>
#include <iso646.h>
#include <limits.h>
#include <math.h>
#include <setjmp.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*============================================================================*/
/* Useful Typedefs                                                            */
/*============================================================================*/

typedef uint8_t  tbyte; /**< Typedef for 8-bit unsigned integer */
typedef uint16_t tword; /**< Typedef for 16-bit unsigned integer */
typedef uint32_t tlong; /**< Typedef for 32-bit unsigned integer */

/*============================================================================*/
/* Core Macros                                                                */
/*============================================================================*/

#define SET_BIT(reg, bit)     ((reg) |= (1U << (bit)))
#define CLR_BIT(reg, bit)     ((reg) &= ~(1U << (bit)))
#define GET_BIT(reg, bit)     (((reg) >> (bit)) & 1U)
#define TOG_BIT(reg, bit)     ((reg) ^= (1U << (bit)))

/* Global Interrupt Control (using CMSIS intrinsics) */
#define DI()                  __disable_irq()           /**< Disable global interrupts */
#define EI()                  __enable_irq()            /**< Enable global interrupts */
#define Global_Int_Disable()  __disable_irq()           /**< Disable global interrupts (alias) */
#define Global_Int_Enable()   __enable_irq()            /**< Enable global interrupts (alias) */

/* System Control */
#define NOP()                 __NOP()                   /**< No Operation */
/* HALT: Enters Sleep mode (wait for interrupt).
 * For deeper modes, specific SCB/PWR register manipulation is needed.
 * WFI is a common simple halt.
 */
#define HALT()                __WFI()                   /**< Wait For Interrupt (enter low-power state) */


/*============================================================================*/
/* Safeguard Macros (Implemented)                                             */
/*============================================================================*/

/**
 * @brief Configures all GPIO ports on STM32F410RC to a safe state.
 *        Sets output data to 0, configures mode to input, disables
 *        pull-up/pull-down resistors and alternate functions.
 *
 * @note This function assumes the necessary GPIO clocks are enabled
 *       or enables them transiently. Clocks are re-enabled before access.
 */
static inline void GPIO_Safeguard_Init_Func(void)
{
    /* Enable clocks for all relevant GPIO ports (A, B, C, D, E, H for F410RC) */
    /* Use __HAL_RCC_GPIOx_CLK_ENABLE() macros if using HAL, otherwise use RCC directly */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();

    /* Configure each port */
    /* Iterate through ports A-E, H */
    GPIO_TypeDef *gpio_ports[] = { GPIOA, GPIOB, GPIOC, GPIOD, GPIOE, GPIOH };
    uint32_t num_ports = sizeof(gpio_ports) / sizeof(gpio_ports[0]);
    uint32_t i;

    for (i = 0U; i < num_ports; i++)
    {
        GPIO_TypeDef *GPIOx = gpio_ports[i];

        /* Set Output Data Register to 0 */
        /* This ensures outputs are low if temporarily configured as output */
        /* Safe to do even for input mode */
        GPIOx->ODR = 0x00000000U;

        /* Configure all pins as Input mode (00) */
        GPIOx->MODER = 0x00000000U;

        /* Disable Pull-up/Pull-down resistors (00) */
        GPIOx->PUPDR = 0x00000000U;

        /* Disable Alternate Function mappings (0000) */
        GPIOx->AFR[0] = 0x00000000U; /* AFR Low */
        GPIOx->AFR[1] = 0x00000000U; /* AFR High */

        /* Optionally, reset other registers like OTYPER, OSPEEDR to default (0) */
        GPIOx->OTYPER = 0x0000; /* Push-Pull (default 0) */
        GPIOx->OSPEEDR = 0x00000000U; /* Low Speed (default 0) */

        /* Disabling wakeup registers is typically handled at the system/PWR level,
         * not per GPIO port unless specific EXTI wakeup is configured.
         * EXTI IT/Event masks are in EXTI registers. Disable relevant EXTI lines if needed.
         * This safeguard focuses on core GPIO configuration.
         */
    }

    /* Note: Disabling the clocks again might be desired depending on power
     * strategy, but leaving them enabled is harmless if GPIO access is expected.
     * For a 'safe' state, turning them off might be better for low power,
     * but requires re-enabling later. Let's leave them enabled for now
     * as peripheral safeguard will turn off non-GPIO clocks.
     */
    /* __HAL_RCC_GPIOA_CLK_DISABLE(); ... etc. */
}

/**
 * @brief Disables global interrupts and resets core peripheral states
 *        on STM32F410RC.
 *        Disables Timers, PWM (via timers), WDT, ICU (via timers), ADC,
 *        UART, I2C, SPI.
 *        Configures all GPIOs as standard I/O (Input) - relies on
 *        GPIO_SAFEGUARD_Init_Func.
 *
 * @note This function disables peripheral clocks and resets key control registers.
 *       It relies on the CMSIS/HAL register definitions.
 */
static inline void Registers_Safeguard_Init_Func(void)
{
    /* Disable global interrupts */
    __disable_irq();

    /* Disable clocks and reset control registers for common peripherals */
    /* RCC AHB1 Peripherals */
    /* Note: GPIO clocks are handled in GPIO_Safeguard_Init_Func */
    RCC->AHB1ENR = RCC->AHB1ENR & ~(
                   RCC_AHB1ENR_CRCEN |
                   RCC_AHB1ENR_FLITFEN | /* Flash interface */
                   RCC_AHB1ENR_SRAMEN    /* SRAM clock */
                   /* Add others if needed, but usually keep essential ones */
                   );

    /* RCC AHB2 Peripherals */
    RCC->AHB2ENR = RCC->AHB2ENR & ~(
                   RCC_AHB2ENR_OTGFSEN /* USB OTG FS */
                   );

    /* RCC APB1 Peripherals */
    /* Timers: TIM2, TIM3, TIM4, TIM5 */
    /* USART2, LPUART1 */
    /* I2C: I2C1, I2C2 */
    /* SPI: SPI2 */
    /* WWDG */
    RCC->APB1ENR = RCC->APB1ENR & ~(
                   RCC_APB1ENR_TIM2EN   | RCC_APB1ENR_TIM3EN   |
                   RCC_APB1ENR_TIM4EN   | RCC_APB1ENR_TIM5EN   |
                   RCC_APB1ENR_WWDGEN   |
                   RCC_APB1ENR_SPI2EN   |
                   RCC_APB1ENR_USART2EN | RCC_APB1ENR_LPUART1EN |
                   RCC_APB1ENR_I2C1EN   | RCC_APB1ENR_I2C2EN   |
                   RCC_APB1ENR_PWREN    /* Power interface clock - keep enabled? Disable for minimal state. */
                   /* Add DACEN, etc if present and needed to disable */
                   );

    /* RCC APB2 Peripherals */
    /* Timers: TIM9, TIM10, TIM11 */
    /* ADC1 */
    /* USART1 */
    /* SPI1, SPI5 */
    /* SYSCFG */
    RCC->APB2ENR = RCC->APB2ENR & ~(
                   RCC_APB2ENR_TIM9EN   | RCC_APB2ENR_TIM10EN  |
                   RCC_APB2ENR_TIM11EN  |
                   RCC_APB2ENR_ADC1EN   |
                   RCC_APB2ENR_USART1EN |
                   RCC_APB2ENR_SPI1EN   | RCC_APB2ENR_SPI5EN   |
                   RCC_APB2ENR_SYSCFGEN /* System configuration controller clock - keep enabled? Disable for minimal state. */
                   /* Add FIREWALLEN, etc if present and needed to disable */
                   );

    /* Reset key control registers after disabling clocks */
    /* Timers */
    TIM2->CR1 = 0U; TIM3->CR1 = 0U; TIM4->CR1 = 0U; TIM5->CR1 = 0U;
    TIM9->CR1 = 0U; TIM10->CR1 = 0U; TIM11->CR1 = 0U;

    /* WWDG */
    WWDG->CR = 0U;
    /* IWDG is slightly different - relies on key register access */
    /* To stop IWDG if running, need unlock, write 0 to RLR, then lock */
    /* A simpler 'safe' state is often just not starting it. */
    /* If already running by hardware option bytes, can't stop via registers. */
    /* We can set key registers to 0 to prevent *starting* from software. */
    IWDG->KR = 0U; /* Write 0 to Key Register */
    IWDG->PR = 0U; /* Write 0 to Prescaler Register */
    IWDG->RLR = 0U; /* Write 0 to Reload Register */

    /* ADC */
    ADC1->CR1 = 0U; ADC1->CR2 = 0U; ADC1->SR = 0U; /* Reset control/status */
    /* Calibration registers might need specific reset logic if applicable */

    /* USARTs */
    USART1->CR1 = 0U; USART2->CR1 = 0U; LPUART1->CR1 = 0U;

    /* I2Cs */
    I2C1->CR1 = 0U; I2C2->CR1 = 0U;

    /* SPIs */
    SPI1->CR1 = 0U; SPI2->CR1 = 0U; SPI5->CR1 = 0U;

    /* Configure all GPIOs as input/standard I/O */
    /* This is handled by GPIO_Safeguard_Init_Func */
    GPIO_Safeguard_Init_Func();

    /* Re-enable interrupts if desired, but typically safeguards are done
     * with interrupts disabled and the application will re-enable them
     * when ready. Leaving them disabled aligns with a 'safe' initial state.
     * __enable_irq();
     */
}


/* Macro definitions to call the safeguard functions */
#define GPIO_SAFEGUARD_Init()      GPIO_Safeguard_Init_Func()
#define Registers_SAFEGUARD_Init() Registers_Safeguard_Init_Func()


/*============================================================================*/
/* Configuration Check Macros (Optional but Good Practice)                    */
/*============================================================================*/

/* Add checks here for required definitions if building a library, e.g.,
 * #ifndef STM32F410RC
 * #error "This header is specific to STM32F410RC"
 * #endif
 */

#endif /* MAIN_H_ */