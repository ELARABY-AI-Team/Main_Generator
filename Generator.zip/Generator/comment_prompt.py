from datetime import datetime

def comment_prompt(mcu_name):
    current_date = datetime.now().strftime("%Y-%m-%d")

    return f"""/***********************************************************************************************************************
* File Name      : let user decide
* Description    : let user decide
* Author         : Technology Inovation Software Team
* Tester         : 
* Device(s)      : {mcu_name}
* Creation Date  : {current_date}
* Testing Date   : 
* @COPYRIGHT : ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP.
***********************************************************************************************************************/"""
