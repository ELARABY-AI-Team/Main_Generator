
import json
from datetime import datetime

# Load saved MCU name
with open("mcu_config.json", "r") as f:
    config = json.load(f)

mcu_name = config.get("mcu_name", "UNKNOWN")
current_date = datetime.now().strftime("%Y-%m-%d")

prompt_comment = f"""/***********************************************************************************************************************
* File Name      : let user decide
* Description    : let user decide
* Author         : Technology Inovation Software Team
* Tester         : 
* Device(s)      : {mcu_name}
* Creation Date  : {current_date}
* Testing Date   : 
* @COPYRIGHT : ELARABY GROUP-TECHNOLOGY & INNOVATION CENTER-EMBEDDED SYSTEM GROUP.
***********************************************************************************************************************/"""
