from datetime import datetime

def config_h_prompt(mcu_name):
    current_date = datetime.now().strftime("%Y-%m-%d")

    return f"""Create a clean, production-ready **config.h** header file for the {mcu_name} microcontroller.  
    This file must define only what is needed for `config.c`, and reuse all typedefs and macros from **main.h**.

    ---

    ### 🔗 Linking to main.h:

    - Add `#include "{mcu_name}_MAIN.h"` at the top (assumes main.h was already generated)
    - DO NOT redefine `tbyte`, `tword`, `tlong`, or bit macros like `SET_BIT()` — they already exist in main.h
    - Reuse GPIO and register safety macros such as `GPIO_SAFEGUARD_Init()` and `Registers_SAFEGUARD_Init()`

    ---

    ### 🔧 Contents:

    1. Add standard include guard: `#ifndef CONFIG_H_`
    2. Wrap with `extern "C"` for C++ compatibility if needed
    3. Declare: donot change all functions are void
    - `void mcu_config_Init(void);`
    - `void WDI_Reset(void);`
    4. If needed:
    - Declare `extern` config state/status variables
    - Add `#define` for optional features (e.g., `ENABLE_WATCHDOG`)
    5. Define symbolic return/error codes (`CONFIG_OK`, `CONFIG_FAIL`)

    ---

    ### 📘 Notes:

    - Keep it minimal and clean — no redundant includes or macro definitions
    - Match naming with `config.c`
    - Add short comments to explain what each part does and if you didnot find or assume a value or register please right a comment beside it says "that you assum that please change it"

    Output must be real code, ready to use, no placeholders or TODOs."""