from datetime import datetime

def config_c_optionbite_prompt(mcu_name):
    current_date = datetime.now().strftime("%Y-%m-%d")

    return f"""Create a clean and production-ready **config.c** file for the {mcu_name} microcontroller in Option Bite mode.  
    This file must implement the functions declared in `config.h`, using the macros and typedefs from `{mcu_name}_MAIN.h`.

    ---

    ### 🔗 File Linkage:

    - Add `#include "{mcu_name}_config.h"` and `#include "{mcu_name}_MAIN.h"` at the top
    - Do not redefine macros like `SET_BIT`, `GPIO_SAFEGUARD_Init()`, or typedefs like `tword` — just use them

    ---

    ### 🔧 Main Initialization Function:

    Implement `void mcu_config_Init(void)` using the following sequence:

    1. `safe_guards()` → should call `GPIO_SAFEGUARD_Init()` and `Registers_SAFEGUARD_Init()`

    Implement `void WDI_Reset(void);` to refresh/reset the watchdog timer.

    ---

    ### 🔒 Visibility Rules:
    Only the following function must be marked static:

    - safe_guards()

    ### ⚠️ Safety Guidelines:

    - Use error codes (`return 0` for success, `<0` for failure)
    - Add timeout checks when polling hardware
    - No magic numbers — use `#define` or values from main.h
    - Short inline comments where needed (e.g. for register access or safety logic)

    ---

    ### 📘 Comments:

    - Add short function headers
    - Keep it clean and readable — no unnecessary comments or placeholders
    - Only comment what's important (e.g. timing-critical code, register logic) if you didnot find or assume a value or register please right a comment beside it says "that you assum that please change it"


    IMPORTANT:
    - Keep the exact function signatures and structure
    - Only modify the implementations inside functions bodies
    - Preserve all static/non-static modifiers
    - Only get the specific values (registers etc)
    

    🛠️ **IMPORTANT INSTRUCTIONS:**
- If you use any value (register name, bit flag, timing value, etc.) from the PDF, add `/* PDF Reference */` beside it.
- If you make an assumption due to missing data, write a comment like: `/* Assumed value – please verify */`
- Keep these comments **on the same line** as the register or logic.
- Format everything clearly and professionally.
"""