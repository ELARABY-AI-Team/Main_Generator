import json

with open("mcu_config.json", "r") as f:
    config = json.load(f)

mcu_name = config.get("mcu_name", "UNKNOWN")


gpio_h_prompt = f"""Generate a production-ready GPIO.h header file for the {mcu_name} microcontroller that strictly follows these requirements:

1. FILE STRUCTURE:
#ifndef {mcu_name}_GPIO_H_
#define {mcu_name}_GPIO_H_
#include "{mcu_name}_Config.h"


/* ==================== REQUIRED ENUMS (DO NOT MODIFY) ==================== */
- t_usage enum:
  - Values: normal_usage, communication_usage
  - Purpose: Define whether the GPIO is used for general or communication-specific logic.

- t_direction enum:
  - Values: output, input, analog
  - Purpose: Define the direction mode of the GPIO pin.

- t_pull enum:
  - Values: pull_up, pull_down
  - Purpose: Define pull resistor settings for input pins.

- t_output_conn enum:
  - Values: push_pull, open_drain
  - Purpose: Define the output driving connection type.


/* ==================== HARDWARE DEFINITIONS ==================== */
- Define a tport enum:
  - Include all available ports for the given microcontroller, such as port_A, port_B, port_C, etc.
  - For each port entry, add a comment indicating:
    - /* PDF Reference */ if it's sourced directly from the datasheet
    - /* Assumed – please verify */ if not found in official docs

- Define a tpin enum:
  - Include available pins, such as pin_0, pin_1, ..., up to the highest supported pin number
  - For each pin entry, annotate with:
    - /* PDF Reference */ or /* Assumed – please verify */ based on the source of information

These enums must be placed in the GPIO.h header file and must follow production-quality embedded C style. Do not include placeholder values, incomplete enums, or missing annotations.

/* ==================== FUNCTION DECLARATIONS ==================== */
void GPIO_Output_Init(tport port, tpin pin, tbyte value, t_usage usage, t_output_conn conn);
void GPIO_Input_Init(tport port, tpin pin, t_usage usage, t_pull pull);
t_direction GPIO_Direction_get(tport port, tpin pin);
void GPIO_Value_Set(tport port, tpin pin, tbyte value);
tbyte GPIO_Value_Get(tport port, tpin pin);
void GPIO_Value_Tog(tport port, tpin pin);

#endif /* {mcu_name}_GPIO_H_ */

/* ==================== STRICT REQUIREMENTS ==================== */

1. CODING STANDARDS:
• Absolute compliance with AUTOSAR/MISRA-C guidelines
• No implementations - declarations only
• Use exact specified enum/function names
• All types (tbyte, tword) from {mcu_name}_MAIN.h
• No additional macros/typedefs
• No static functions
• Single-line comments only

2. OUTPUT:
• Fully compilable C header
• Production-grade quality
• No placeholders or TODOs
• Automotive/mission-critical safety level"""